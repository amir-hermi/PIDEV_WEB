<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* base.html.twig */
class __TwigTemplate_d9877dd0e39f1521ed25d99cd653a789ad8ce762d5b34cf60fe62d78287c101d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'css' => [$this, 'block_css'],
            'js' => [$this, 'block_js'],
            'header' => [$this, 'block_header'],
            'ShowLogin' => [$this, 'block_ShowLogin'],
            'panier' => [$this, 'block_panier'],
            'actHome' => [$this, 'block_actHome'],
            'actProduct' => [$this, 'block_actProduct'],
            'actAbout' => [$this, 'block_actAbout'],
            'actCommande' => [$this, 'block_actCommande'],
            'actRec' => [$this, 'block_actRec'],
            'banner' => [$this, 'block_banner'],
            'body' => [$this, 'block_body'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->";
        // line 6
        $context["sum"] = (isset($context["sumP"]) || array_key_exists("sumP", $context) ? $context["sumP"] : (function () { throw new RuntimeError('Variable "sumP" does not exist.', 6, $this->source); })());
        // line 7
        echo "<!DOCTYPE html>
<html>
<head>
    <title>Women's Fashion a Ecommerce Online Shopping Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
    <!-- for-mobile-apps -->
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    <meta name=\"keywords\" content=\"Women's Fashion Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />
    <script type=\"application/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- //for-mobile-apps -->
    ";
        // line 19
        $this->displayBlock('css', $context, $blocks);
        // line 26
        echo "    ";
        $this->displayBlock('js', $context, $blocks);
        // line 51
        echo "    <!-- //end-smooth-scrolling -->
</head>

<body>
<!-- header -->
";
        // line 56
        $this->displayBlock('header', $context, $blocks);
        // line 251
        $this->displayBlock('banner', $context, $blocks);
        // line 1123
        echo "

";
        // line 1125
        $this->displayBlock('body', $context, $blocks);
        // line 1381
        $this->displayBlock('footer', $context, $blocks);
        // line 1447
        echo "</body>
</html>";
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 19
    public function block_css($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "css"));

        // line 20
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/bootstrap.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
    <link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
    <link href=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/fasthover.css"), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
        <link href='//fonts.googleapis.com/css?family=Glegoo:400,700' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 26
    public function block_js($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "js"));

        // line 27
        echo "    <!-- js -->
    <script src=\"";
        // line 28
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/jquery.min.js"), "html", null, true);
        echo "\"></script>
    <!-- //js -->
    <!-- countdown -->
    <link rel=\"stylesheet\" href=\"";
        // line 31
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("css/jquery.countdown.css"), "html", null, true);
        echo "\" />
    <!-- //countdown -->
    <!-- cart -->
    <script src=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/simpleCart.min.js"), "html", null, true);
        echo "\"></script>
    <!-- cart -->
    <!-- for bootstrap working -->
    <script type=\"text/javascript\" src=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/bootstrap-3.1.1.min.js"), "html", null, true);
        echo "\"></script>
    <!-- //for bootstrap working -->

    <!-- start-smooth-scrolling -->
    <script type=\"text/javascript\">
        jQuery(document).ready(function(\$) {
            \$(\".scroll\").click(function(event){
                event.preventDefault();
                \$('html,body').animate({scrollTop:\$(this.hash).offset().top},1000);
            });
        });
    </script>

    ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 56
    public function block_header($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "header"));

        // line 57
        echo "
<div class=\"modal fade\" id=\"myModal88\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal88\"
     aria-hidden=\"true\">
    <div class=\"modal-dialog modal-lg\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">
                    &times;</button>
                <h4 class=\"modal-title\" id=\"myModalLabel\">
                    Don't Wait, Login now!</h4>
            </div>
            <div class=\"modal-body modal-body-sub\">
                <div class=\"row\">
                    <div class=\"col-md-8 modal_body_left modal_body_left1\" style=\"border-right: 1px dotted #C2C2C2;padding-right:3em;\">
                        <div class=\"sap_tabs\">
                            <div id=\"horizontalTab\" style=\"display: block; width: 100%; margin: 0px;\">
                                <ul>
                                    <li class=\"resp-tab-item\" aria-controls=\"tab_item-0\"><span>Sign in</span></li>
                                    <li class=\"resp-tab-item\" aria-controls=\"tab_item-1\"><span>Sign up</span></li>
                                </ul>
                                <div class=\"tab-1 resp-tab-content\" aria-labelledby=\"tab_item-0\">
                                    <div class=\"facts\">
                                        <div class=\"register\">
                                            <form action=\"#\" method=\"post\">
                                                <input name=\"Email\" placeholder=\"Email Address\" type=\"text\" required=\"\">
                                                <input name=\"Password\" placeholder=\"Password\" type=\"password\" required=\"\">
                                                <div class=\"sign-up\">
                                                    <input type=\"submit\" value=\"Sign in\"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class=\"tab-2 resp-tab-content\" aria-labelledby=\"tab_item-1\">
                                    <div class=\"facts\">
                                        <div class=\"register\">
                                            <form action=\"#\" method=\"post\">
                                                <input placeholder=\"Name\" name=\"Name\" type=\"text\" required=\"\">
                                                <input placeholder=\"Email Address\" name=\"Email\" type=\"email\" required=\"\">
                                                <input placeholder=\"Password\" name=\"Password\" type=\"password\" required=\"\">
                                                <input placeholder=\"Confirm Password\" name=\"Password\" type=\"password\" required=\"\">
                                                <div class=\"sign-up\">
                                                    <input type=\"submit\" value=\"Create Account\"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <script src=\"js/easyResponsiveTabs.js\" type=\"text/javascript\"></script>
                        <script type=\"text/javascript\">
                            \$(document).ready(function () {
                                \$('#horizontalTab').easyResponsiveTabs({
                                    type: 'default', //Types: default, vertical, accordion
                                    width: 'auto', //auto or any width like 600px
                                    fit: true   // 100% fit in a container
                                });
                            });
                        </script>
                        <div id=\"OR\" class=\"hidden-xs\">
                            OR</div>
                    </div>
                    <div class=\"col-md-4 modal_body_right modal_body_right1\">
                        <div class=\"row text-center sign-with\">
                            <div class=\"col-md-12\">
                                <h3 class=\"other-nw\">
                                    Sign in with</h3>
                            </div>
                            <div class=\"col-md-12\">
                                <ul class=\"social\">
                                    <li class=\"social_facebook\"><a href=\"#\" class=\"entypo-facebook\"></a></li>
                                    <li class=\"social_dribbble\"><a href=\"#\" class=\"entypo-dribbble\"></a></li>
                                    <li class=\"social_twitter\"><a href=\"#\" class=\"entypo-twitter\"></a></li>
                                    <li class=\"social_behance\"><a href=\"#\" class=\"entypo-behance\"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    ";
        // line 142
        $this->displayBlock('ShowLogin', $context, $blocks);
        // line 147
        echo "<div class=\"header\">
    <div class=\"container\">

        <div class=\"w3l_login\">
            <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal88\"><span class=\"glyphicon glyphicon-user\" aria-hidden=\"true\"></span></a>
        </div>
        <div class=\"w3l_logo\">
            <h1><a href=\"";
        // line 154
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\">SportTech<span>For sport Lovers </span></a></h1>
        </div>
        <div class=\"search\">
            <input class=\"search_box\" type=\"checkbox\" id=\"search_box\">
            <label class=\"icon-search\" for=\"search_box\"><span class=\"glyphicon glyphicon-search\" aria-hidden=\"true\"></span></label>
            <div class=\"search_form\">
                <form action=\"#\" method=\"post\">
                    <input type=\"text\" name=\"Search\" placeholder=\"Search...\">
                    <input type=\"submit\" value=\"Send\">
                </form>
            </div>
        </div>
        <div class=\"cart box_1\">
           ";
        // line 167
        $this->displayBlock('panier', $context, $blocks);
        // line 173
        echo "            <p><a href=\"javascript:;\" class=\"simpleCart_empty\">Empty Cart</a></p>
            <div class=\"clearfix\"> </div>
        </div>
        <div class=\"clearfix\"> </div>
    </div>
</div>
<div class=\"navigation\">
    <div class=\"container\">
        <nav class=\"navbar navbar-default\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header nav_2\">
                <button type=\"button\" class=\"navbar-toggle collapsed navbar-toggle1\" data-toggle=\"collapse\" data-target=\"#bs-megadropdown-tabs\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"bs-megadropdown-tabs\">
                <ul class=\"nav navbar-nav\">
                    <li ><a href=\"";
        // line 193
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\"";
        $this->displayBlock('actHome', $context, $blocks);
        echo ">Home</a></li>
                    <!-- Mega Menu -->
                    <li class=\"dropdown\">
                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" ";
        // line 196
        $this->displayBlock('actProduct', $context, $blocks);
        echo ">Produits <b class=\"caret\"></b></a>
                        <ul class=\"dropdown-menu multi-column columns-3\">
                            <div class=\"row\">
                                <div class=\"col-sm-3\">
                                    <ul class=\"multi-column-dropdown\">
                                        <h6>Hommes</h6>
                                        <li><a href=\"";
        // line 202
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Dresses<span>New</span></a></li>
                                        <li><a href=\"sweaters.html\">Sweaters</a></li>
                                        <li><a href=\"skirts.html\">Shorts & Skirts</a></li>
                                        <li><a href=\"jeans.html\">Jeans</a></li>
                                        <li><a href=\"shirts.html\">Shirts & Tops<span>New</span></a></li>
                                    </ul>
                                </div>
                                <div class=\"col-sm-3\">
                                    <ul class=\"multi-column-dropdown\">
                                        <h6>Femmes</h6>
                                        <li><a href=\"salwars.html\">Salwars</a></li>
                                        <li><a href=\"sarees.html\">Sarees<span>New</span></a></li>
                                        <li><a href=\"products.html\"><i>Summer Store</i></a></li>
                                    </ul>
                                </div>
                                <div class=\"col-sm-3\">
                                    <ul class=\"multi-column-dropdown\">
                                        <h6>Materiel sport</h6>
                                        <li><a href=\"sandals.html\">Flats</a></li>
                                        <li><a href=\"sandals.html\">Sandals</a></li>
                                        <li><a href=\"sandals.html\">Boots</a></li>
                                        <li><a href=\"sandals.html\">Heels</a></li>
                                    </ul>
                                </div>
                                <div class=\"col-sm-3\">
                                    <ul class=\"multi-column-dropdown\">
                                        <h6>Materiel musculation</h6>
                                        <li><a href=\"";
        // line 229
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Dresses<span>New</span></a></li>
                                        <li><a href=\"sweaters.html\">Sweaters</a></li>
                                        <li><a href=\"skirts.html\">Shorts & Skirts</a></li>
                                        <li><a href=\"jeans.html\">Jeans</a></li>
                                        <li><a href=\"shirts.html\">Shirts & Tops<span>New</span></a></li>
                                    </ul>

                                <div class=\"clearfix\"></div>
                            </div>
                            </div>
                        </ul>
                    </li>
                    <li><a href=\"";
        // line 241
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("about");
        echo "\"";
        $this->displayBlock('actAbout', $context, $blocks);
        echo ">A propos de nous</a></li>
                    <li><a href=\"";
        // line 242
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("commande");
        echo "\"";
        $this->displayBlock('actCommande', $context, $blocks);
        echo ">Commandes</a></li>
                    <li><a href=\"";
        // line 243
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("reclamation");
        echo "\"";
        $this->displayBlock('actRec', $context, $blocks);
        echo ">Reclamation</a></li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<!-- //header -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 142
    public function block_ShowLogin($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        // line 143
        echo "<script>
    \$('#myModal88').modal('show');
</script>
        ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 167
    public function block_panier($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "panier"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "panier"));

        echo " <a href=\"";
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("panier");
        echo "\">
                <div class=\"total\">
                    <span >";
        // line 169
        echo twig_escape_filter($this->env, (isset($context["total"]) || array_key_exists("total", $context) ? $context["total"] : (function () { throw new RuntimeError('Variable "total" does not exist.', 169, $this->source); })()), "html", null, true);
        echo ".00</span> (";
        echo twig_escape_filter($this->env, (isset($context["sum"]) || array_key_exists("sum", $context) ? $context["sum"] : (function () { throw new RuntimeError('Variable "sum" does not exist.', 169, $this->source); })()), "html", null, true);
        echo "</span> items)</div>
                <img src=\"images/bag.png\" alt=\"\" />
            </a>
            ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 193
    public function block_actHome($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actHome"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actHome"));

        echo "  ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 196
    public function block_actProduct($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actProduct"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actProduct"));

        echo " ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 241
    public function block_actAbout($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actAbout"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actAbout"));

        echo "  ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 242
    public function block_actCommande($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actCommande"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actCommande"));

        echo "  ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 243
    public function block_actRec($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actRec"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actRec"));

        echo "  ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 251
    public function block_banner($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        // line 252
        echo "<!-- banner -->
<div class=\"banner\" id=\"home1\">
    <div class=\"container\">
        <h3>fashions fade, <span>style is eternal</span></h3>
    </div>
</div>
<!-- //banner -->

<!-- banner-bottom -->
<div class=\"banner-bottom\">
    <div class=\"container\">
        <div class=\"col-md-5 wthree_banner_bottom_left\">
            <div class=\"video-img\">
                <a class=\"play-icon popup-with-zoom-anim\" href=\"#small-dialog\">
                    <span class=\"glyphicon glyphicon-expand\" aria-hidden=\"true\"></span>
                </a>
            </div>
            <!-- pop-up-box -->
            <link href=\"css/popuo-box.css\" rel=\"stylesheet\" type=\"text/css\" property=\"\" media=\"all\" />
            <script src=\"js/jquery.magnific-popup.js\" type=\"text/javascript\"></script>
            <!--//pop-up-box -->
            <div id=\"small-dialog\" class=\"mfp-hide\">
                <iframe src=\"https://player.vimeo.com/video/23259282?title=0&byline=0&portrait=0\"></iframe>
            </div>
            <script>
                \$(document).ready(function() {
                    \$('.popup-with-zoom-anim').magnificPopup({
                        type: 'inline',
                        fixedContentPos: false,
                        fixedBgPos: true,
                        overflowY: 'auto',
                        closeBtnInside: true,
                        preloader: false,
                        midClick: true,
                        removalDelay: 300,
                        mainClass: 'my-mfp-zoom-in'
                    });

                });
            </script>
        </div>
        <div class=\"col-md-7 wthree_banner_bottom_right\">
            <div class=\"bs-example bs-example-tabs\" role=\"tabpanel\" data-example-id=\"togglable-tabs\">
                <ul id=\"myTab\" class=\"nav nav-tabs\" role=\"tablist\">
                    <li role=\"presentation\" class=\"active\"><a href=\"#home\" id=\"home-tab\" role=\"tab\" data-toggle=\"tab\" aria-controls=\"home\">T-shirts</a></li>
                    <li role=\"presentation\"><a href=\"#skirts\" role=\"tab\" id=\"skirts-tab\" data-toggle=\"tab\" aria-controls=\"skirts\">Skirts</a></li>
                    <li role=\"presentation\"><a href=\"#watches\" role=\"tab\" id=\"watches-tab\" data-toggle=\"tab\" aria-controls=\"watches\">Watches</a></li>
                    <li role=\"presentation\"><a href=\"#sandals\" role=\"tab\" id=\"sandals-tab\" data-toggle=\"tab\" aria-controls=\"sandals\">Sandals</a></li>
                    <li role=\"presentation\"><a href=\"#jewellery\" role=\"tab\" id=\"jewellery-tab\" data-toggle=\"tab\" aria-controls=\"jewellery\">Jewellery</a></li>
                </ul>
                <div id=\"myTabContent\" class=\"tab-content\">
                    <div role=\"tabpanel\" class=\"tab-pane fade active in\" id=\"home\" aria-labelledby=\"home-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/4.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/7.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">T-Shirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/4.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/7.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">T-Shirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/4.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/7.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">T-Shirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                    <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"skirts\" aria-labelledby=\"skirts-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Skirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Skirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Skirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                    <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"watches\" aria-labelledby=\"watches-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal2\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Watch</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal2\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Watch</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal2\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Watch</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                    <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"sandals\" aria-labelledby=\"sandals-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Sandal</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Sandal</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Sandal</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                    <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"jewellery\" aria-labelledby=\"jewellery-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal4\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Jewellery</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal4\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Jewellery</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal4\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Jewellery</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--modal-video-->
            <div class=\"modal video-modal fade\" id=\"myModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/20.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's shirt</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal1\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/63.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look black women's jeans</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal2\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal2\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/23.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Watch</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal3\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal3\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/24.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Sandal</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal4\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal4\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/22.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Necklace</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal5\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal5\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/35.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Jacket</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal6\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal6\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/39.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Long Skirt</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"clearfix\"> </div>
    </div>
</div>
<!-- //banner-bottom -->

<!-- banner-bottom1 -->
<div class=\"banner-bottom1\">
    <div class=\"agileinfo_banner_bottom1_grids\">
        <div class=\"col-md-7 agileinfo_banner_bottom1_grid_left\">
            <h3>Grand Opening Event With flat<span>20% <i>Discount</i></span></h3>
            <a href=\"products.html\">Shop Now</a>
        </div>
        <div class=\"col-md-5 agileinfo_banner_bottom1_grid_right\">
            <h4>hot deal</h4>
            <div class=\"timer_wrap\">
                <div id=\"counter\"> </div>
            </div>
            <script src=\"js/jquery.countdown.js\"></script>
            <script src=\"js/script.js\"></script>
        </div>
        <div class=\"clearfix\"> </div>
    </div>
</div>
<!-- //banner-bottom1 -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 1125
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 1126
        echo "<!-- special-deals -->
<div class=\"special-deals\">
    <div class=\"container\">
        <h2>Special Deals</h2>
        <div class=\"w3agile_special_deals_grids\">
            <div class=\"col-md-7 w3agile_special_deals_grid_left\">
                <div class=\"w3agile_special_deals_grid_left_grid\">
                    <img src=\"images/26.jpg\" alt=\" \" class=\"img-responsive\" />
                    <div class=\"w3agile_special_deals_grid_left_grid_pos1\">
                        <h5>30%<span>Off/-</span></h5>
                    </div>
                    <div class=\"w3agile_special_deals_grid_left_grid_pos\">
                        <h4>We Offer <span>Best Products</span></h4>
                    </div>
                </div>
                <div class=\"wmuSlider example1\">
                    <div class=\"wmuSliderWrapper\">
                        <article style=\"position: absolute; width: 100%; opacity: 0;\">
                            <div class=\"banner-wrap\">
                                <div class=\"w3agile_special_deals_grid_left_grid1\">
                                    <img src=\"images/1.png\" alt=\" \" class=\"img-responsive\" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Laura</h4>
                                </div>
                            </div>
                        </article>
                        <article style=\"position: absolute; width: 100%; opacity: 0;\">
                            <div class=\"banner-wrap\">
                                <div class=\"w3agile_special_deals_grid_left_grid1\">
                                    <img src=\"images/2.png\" alt=\" \" class=\"img-responsive\" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Michael</h4>
                                </div>
                            </div>
                        </article>
                        <article style=\"position: absolute; width: 100%; opacity: 0;\">
                            <div class=\"banner-wrap\">
                                <div class=\"w3agile_special_deals_grid_left_grid1\">
                                    <img src=\"images/3.png\" alt=\" \" class=\"img-responsive\" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Rosy</h4>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
                <script src=\"js/jquery.wmuSlider.js\"></script>
                <script>
                    \$('.example1').wmuSlider();
                </script>
            </div>
            <div class=\"col-md-5 w3agile_special_deals_grid_right\">
                <img src=\"images/25.jpg\" alt=\" \" class=\"img-responsive\" />
                <div class=\"w3agile_special_deals_grid_right_pos\">
                    <h4>Women's <span>Special</span></h4>
                    <h5>save up <span>to</span> 30%</h5>
                </div>
            </div>
            <div class=\"clearfix\"> </div>
        </div>
    </div>
</div>
<!-- //special-deals -->
<!-- new-products -->
<div class=\"new-products\">
    <div class=\"container\">
        <h3>New Products</h3>
        <div class=\"agileinfo_new_products_grids\">
            <div class=\"col-md-3 agileinfo_new_products_grid\">
                <div class=\"agile_ecommerce_tab_left agileinfo_new_products_grid1\">
                    <div class=\"hs-wrapper hs-wrapper1\">
                        <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/29.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/29.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                        <div class=\"w3_hs_bottom w3_hs_bottom_sub\">
                            <ul>
                                <li>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href=\"single.html\">Skirts</a></h5>
                    <div class=\"simpleCart_shelfItem\">
                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                    </div>
                </div>
            </div>
            <div class=\"col-md-3 agileinfo_new_products_grid\">
                <div class=\"agile_ecommerce_tab_left agileinfo_new_products_grid1\">
                    <div class=\"hs-wrapper hs-wrapper1\">
                        <img src=\"images/31.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/32.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/33.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/34.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/31.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/32.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/33.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/34.jpg\" alt=\" \" class=\"img-responsive\" />
                        <div class=\"w3_hs_bottom w3_hs_bottom_sub\">
                            <ul>
                                <li>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal5\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href=\"single.html\">Jackets</a></h5>
                    <div class=\"simpleCart_shelfItem\">
                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                    </div>
                </div>
            </div>
            <div class=\"col-md-3 agileinfo_new_products_grid\">
                <div class=\"agile_ecommerce_tab_left agileinfo_new_products_grid1\">
                    <div class=\"hs-wrapper hs-wrapper1\">
                        <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                        <div class=\"w3_hs_bottom w3_hs_bottom_sub\">
                            <ul>
                                <li>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href=\"single.html\">Dresses</a></h5>
                    <div class=\"simpleCart_shelfItem\">
                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                    </div>
                </div>
            </div>
            <div class=\"col-md-3 agileinfo_new_products_grid\">
                <div class=\"agile_ecommerce_tab_left agileinfo_new_products_grid1\">
                    <div class=\"hs-wrapper hs-wrapper1\">
                        <img src=\"images/40.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/42.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/43.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/40.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/42.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/43.jpg\" alt=\" \" class=\"img-responsive\" />
                        <div class=\"w3_hs_bottom w3_hs_bottom_sub\">
                            <ul>
                                <li>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal1\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href=\"single.html\">Jeans</a></h5>
                    <div class=\"simpleCart_shelfItem\">
                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                    </div>
                </div>
            </div>
            <div class=\"clearfix\"> </div>
        </div>
    </div>
</div>
<!-- //new-products -->
<!-- top-brands -->
<div class=\"top-brands\">
    <div class=\"container\">
        <h3>Top Brands</h3>
        <div class=\"sliderfig\">
            <ul id=\"flexiselDemo1\">
                <li>
                    <img src=\"images/4.png\" alt=\" \" class=\"img-responsive\" />
                </li>
                <li>
                    <img src=\"images/5.png\" alt=\" \" class=\"img-responsive\" />
                </li>
                <li>
                    <img src=\"images/6.png\" alt=\" \" class=\"img-responsive\" />
                </li>
                <li>
                    <img src=\"images/7.png\" alt=\" \" class=\"img-responsive\" />
                </li>
                <li>
                    <img src=\"images/46.jpg\" alt=\" \" class=\"img-responsive\" />
                </li>
            </ul>
        </div>
        <script type=\"text/javascript\">
            \$(window).load(function() {
                \$(\"#flexiselDemo1\").flexisel({
                    visibleItems: 4,
                    animationSpeed: 1000,
                    autoPlay: true,
                    autoPlaySpeed: 3000,
                    pauseOnHover: true,
                    enableResponsiveBreakpoints: true,
                    responsiveBreakpoints: {
                        portrait: {
                            changePoint:480,
                            visibleItems: 1
                        },
                        landscape: {
                            changePoint:640,
                            visibleItems:2
                        },
                        tablet: {
                            changePoint:768,
                            visibleItems: 3
                        }
                    }
                });

            });
        </script>
        <script type=\"text/javascript\" src=\"js/jquery.flexisel.js\"></script>
    </div>
</div>
<!-- //top-brands -->
<!-- newsletter -->
<div class=\"newsletter\">
    <div class=\"container\">
        <div class=\"col-md-6 w3agile_newsletter_left\">
            <h3>Newsletter</h3>
            <p>Excepteur sint occaecat cupidatat non proident, sunt.</p>
        </div>
        <div class=\"col-md-6 w3agile_newsletter_right\">
            <form action=\"#\" method=\"post\">
                <input type=\"email\" name=\"Email\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">
                <input type=\"submit\" value=\"\" />
            </form>
        </div>
        <div class=\"clearfix\"> </div>
    </div>
</div>
<!-- //newsletter -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 1381
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 1382
        echo "<!-- footer -->
<div class=\"footer\">
    <div class=\"container\">
        <div class=\"w3_footer_grids\">
            <div class=\"col-md-3 w3_footer_grid\">
                <h3>Contact</h3>
                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse.</p>
                <ul class=\"address\">
                    <li><i class=\"glyphicon glyphicon-map-marker\" aria-hidden=\"true\"></i>1234k Avenue, 4th block, <span>New York City.</span></li>
                    <li><i class=\"glyphicon glyphicon-envelope\" aria-hidden=\"true\"></i><a href=\"mailto:info@example.com\">info@example.com</a></li>
                    <li><i class=\"glyphicon glyphicon-earphone\" aria-hidden=\"true\"></i>+1234 567 567</li>
                </ul>
            </div>
            <div class=\"col-md-3 w3_footer_grid\">
                <h3>Information</h3>
                <ul class=\"info\">
                    <li><a href=\"about.html\">About Us</a></li>
                    <li><a href=\"mail.html\">Contact Us</a></li>
                    <li><a href=\"short-codes.html\">Short Codes</a></li>
                    <li><a href=\"faq.html\">FAQ's</a></li>
                    <li><a href=\"products.html\">Special Products</a></li>
                </ul>
            </div>
            <div class=\"col-md-3 w3_footer_grid\">
                <h3>Category</h3>
                <ul class=\"info\">
                    <li><a href=\"dresses.html\">Dresses</a></li>
                    <li><a href=\"sweaters.html\">Sweaters</a></li>
                    <li><a href=\"shirts.html\">Shirts</a></li>
                    <li><a href=\"sarees.html\">Sarees</a></li>
                    <li><a href=\"skirts.html\">Shorts & Skirts</a></li>
                </ul>
            </div>
            <div class=\"col-md-3 w3_footer_grid\">
                <h3>Profile</h3>
                <ul class=\"info\">
                    <li><a href=\"products.html\">Summer Store</a></li>
                    <li><a href=\"checkout.html\">My Cart</a></li>
                </ul>
                <h4>Follow Us</h4>
                <div class=\"agileits_social_button\">
                    <ul>
                        <li><a href=\"#\" class=\"facebook\"> </a></li>
                        <li><a href=\"#\" class=\"twitter\"> </a></li>
                        <li><a href=\"#\" class=\"google\"> </a></li>
                        <li><a href=\"#\" class=\"pinterest\"> </a></li>
                    </ul>
                </div>
            </div>
            <div class=\"clearfix\"> </div>
        </div>
    </div>
    <div class=\"footer-copy\">
        <div class=\"footer-copy1\">
            <div class=\"footer-copy-pos\">
                <a href=\"#home1\" class=\"scroll\"><img src=\"images/arrow.png\" alt=\" \" class=\"img-responsive\" /></a>
            </div>
        </div>
        <div class=\"container\">
            <p>&copy; 2016 Women's Fashion. All rights reserved | Design by <a href=\"http://w3layouts.com/\">W3layouts</a></p>
        </div>
    </div>
</div>
<!-- //footer -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1764 => 1382,  1754 => 1381,  1490 => 1126,  1480 => 1125,  600 => 252,  590 => 251,  571 => 243,  552 => 242,  533 => 241,  514 => 196,  495 => 193,  479 => 169,  464 => 167,  451 => 143,  441 => 142,  421 => 243,  415 => 242,  409 => 241,  394 => 229,  364 => 202,  355 => 196,  347 => 193,  325 => 173,  323 => 167,  307 => 154,  298 => 147,  296 => 142,  209 => 57,  199 => 56,  175 => 37,  169 => 34,  163 => 31,  157 => 28,  154 => 27,  144 => 26,  130 => 22,  124 => 20,  114 => 19,  103 => 1447,  101 => 1381,  99 => 1125,  95 => 1123,  93 => 251,  91 => 56,  84 => 51,  81 => 26,  79 => 19,  65 => 7,  63 => 6,  56 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->{% set sum = sumP %}
<!DOCTYPE html>
<html>
<head>
    <title>Women's Fashion a Ecommerce Online Shopping Category Flat Bootstrap Responsive Website Template | Home :: w3layouts</title>
    <!-- for-mobile-apps -->
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
    <meta name=\"keywords\" content=\"Women's Fashion Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design\" />
    <script type=\"application/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false);
        function hideURLbar(){ window.scrollTo(0,1); } </script>
    <!-- //for-mobile-apps -->
    {% block css %}
    <link href=\"{{ asset('css/bootstrap.css') }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
    <link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
    <link href=\"{{ asset('css/fasthover.css') }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
        <link href='//fonts.googleapis.com/css?family=Glegoo:400,700' rel='stylesheet' type='text/css'>
        <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    {% endblock %}
    {% block js %}
    <!-- js -->
    <script src=\"{{ asset('js/jquery.min.js') }}\"></script>
    <!-- //js -->
    <!-- countdown -->
    <link rel=\"stylesheet\" href=\"{{ asset('css/jquery.countdown.css') }}\" />
    <!-- //countdown -->
    <!-- cart -->
    <script src=\"{{ asset('js/simpleCart.min.js') }}\"></script>
    <!-- cart -->
    <!-- for bootstrap working -->
    <script type=\"text/javascript\" src=\"{{ asset('js/bootstrap-3.1.1.min.js') }}\"></script>
    <!-- //for bootstrap working -->

    <!-- start-smooth-scrolling -->
    <script type=\"text/javascript\">
        jQuery(document).ready(function(\$) {
            \$(\".scroll\").click(function(event){
                event.preventDefault();
                \$('html,body').animate({scrollTop:\$(this.hash).offset().top},1000);
            });
        });
    </script>

    {% endblock %}
    <!-- //end-smooth-scrolling -->
</head>

<body>
<!-- header -->
{% block header %}

<div class=\"modal fade\" id=\"myModal88\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal88\"
     aria-hidden=\"true\">
    <div class=\"modal-dialog modal-lg\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-hidden=\"true\">
                    &times;</button>
                <h4 class=\"modal-title\" id=\"myModalLabel\">
                    Don't Wait, Login now!</h4>
            </div>
            <div class=\"modal-body modal-body-sub\">
                <div class=\"row\">
                    <div class=\"col-md-8 modal_body_left modal_body_left1\" style=\"border-right: 1px dotted #C2C2C2;padding-right:3em;\">
                        <div class=\"sap_tabs\">
                            <div id=\"horizontalTab\" style=\"display: block; width: 100%; margin: 0px;\">
                                <ul>
                                    <li class=\"resp-tab-item\" aria-controls=\"tab_item-0\"><span>Sign in</span></li>
                                    <li class=\"resp-tab-item\" aria-controls=\"tab_item-1\"><span>Sign up</span></li>
                                </ul>
                                <div class=\"tab-1 resp-tab-content\" aria-labelledby=\"tab_item-0\">
                                    <div class=\"facts\">
                                        <div class=\"register\">
                                            <form action=\"#\" method=\"post\">
                                                <input name=\"Email\" placeholder=\"Email Address\" type=\"text\" required=\"\">
                                                <input name=\"Password\" placeholder=\"Password\" type=\"password\" required=\"\">
                                                <div class=\"sign-up\">
                                                    <input type=\"submit\" value=\"Sign in\"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                                <div class=\"tab-2 resp-tab-content\" aria-labelledby=\"tab_item-1\">
                                    <div class=\"facts\">
                                        <div class=\"register\">
                                            <form action=\"#\" method=\"post\">
                                                <input placeholder=\"Name\" name=\"Name\" type=\"text\" required=\"\">
                                                <input placeholder=\"Email Address\" name=\"Email\" type=\"email\" required=\"\">
                                                <input placeholder=\"Password\" name=\"Password\" type=\"password\" required=\"\">
                                                <input placeholder=\"Confirm Password\" name=\"Password\" type=\"password\" required=\"\">
                                                <div class=\"sign-up\">
                                                    <input type=\"submit\" value=\"Create Account\"/>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <script src=\"js/easyResponsiveTabs.js\" type=\"text/javascript\"></script>
                        <script type=\"text/javascript\">
                            \$(document).ready(function () {
                                \$('#horizontalTab').easyResponsiveTabs({
                                    type: 'default', //Types: default, vertical, accordion
                                    width: 'auto', //auto or any width like 600px
                                    fit: true   // 100% fit in a container
                                });
                            });
                        </script>
                        <div id=\"OR\" class=\"hidden-xs\">
                            OR</div>
                    </div>
                    <div class=\"col-md-4 modal_body_right modal_body_right1\">
                        <div class=\"row text-center sign-with\">
                            <div class=\"col-md-12\">
                                <h3 class=\"other-nw\">
                                    Sign in with</h3>
                            </div>
                            <div class=\"col-md-12\">
                                <ul class=\"social\">
                                    <li class=\"social_facebook\"><a href=\"#\" class=\"entypo-facebook\"></a></li>
                                    <li class=\"social_dribbble\"><a href=\"#\" class=\"entypo-dribbble\"></a></li>
                                    <li class=\"social_twitter\"><a href=\"#\" class=\"entypo-twitter\"></a></li>
                                    <li class=\"social_behance\"><a href=\"#\" class=\"entypo-behance\"></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    {% block ShowLogin %}
<script>
    \$('#myModal88').modal('show');
</script>
        {% endblock %}
<div class=\"header\">
    <div class=\"container\">

        <div class=\"w3l_login\">
            <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal88\"><span class=\"glyphicon glyphicon-user\" aria-hidden=\"true\"></span></a>
        </div>
        <div class=\"w3l_logo\">
            <h1><a href=\"{{ path('home') }}\">SportTech<span>For sport Lovers </span></a></h1>
        </div>
        <div class=\"search\">
            <input class=\"search_box\" type=\"checkbox\" id=\"search_box\">
            <label class=\"icon-search\" for=\"search_box\"><span class=\"glyphicon glyphicon-search\" aria-hidden=\"true\"></span></label>
            <div class=\"search_form\">
                <form action=\"#\" method=\"post\">
                    <input type=\"text\" name=\"Search\" placeholder=\"Search...\">
                    <input type=\"submit\" value=\"Send\">
                </form>
            </div>
        </div>
        <div class=\"cart box_1\">
           {% block panier%} <a href=\"{{ path('panier') }}\">
                <div class=\"total\">
                    <span >{{ total }}.00</span> ({{sum}}</span> items)</div>
                <img src=\"images/bag.png\" alt=\"\" />
            </a>
            {%endblock %}
            <p><a href=\"javascript:;\" class=\"simpleCart_empty\">Empty Cart</a></p>
            <div class=\"clearfix\"> </div>
        </div>
        <div class=\"clearfix\"> </div>
    </div>
</div>
<div class=\"navigation\">
    <div class=\"container\">
        <nav class=\"navbar navbar-default\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header nav_2\">
                <button type=\"button\" class=\"navbar-toggle collapsed navbar-toggle1\" data-toggle=\"collapse\" data-target=\"#bs-megadropdown-tabs\">
                    <span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
            </div>
            <div class=\"collapse navbar-collapse\" id=\"bs-megadropdown-tabs\">
                <ul class=\"nav navbar-nav\">
                    <li ><a href=\"{{ path('home') }}\"{% block actHome%}  {% endblock %}>Home</a></li>
                    <!-- Mega Menu -->
                    <li class=\"dropdown\">
                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" {% block actProduct%} {% endblock %}>Produits <b class=\"caret\"></b></a>
                        <ul class=\"dropdown-menu multi-column columns-3\">
                            <div class=\"row\">
                                <div class=\"col-sm-3\">
                                    <ul class=\"multi-column-dropdown\">
                                        <h6>Hommes</h6>
                                        <li><a href=\"{{ path('products') }}\">Dresses<span>New</span></a></li>
                                        <li><a href=\"sweaters.html\">Sweaters</a></li>
                                        <li><a href=\"skirts.html\">Shorts & Skirts</a></li>
                                        <li><a href=\"jeans.html\">Jeans</a></li>
                                        <li><a href=\"shirts.html\">Shirts & Tops<span>New</span></a></li>
                                    </ul>
                                </div>
                                <div class=\"col-sm-3\">
                                    <ul class=\"multi-column-dropdown\">
                                        <h6>Femmes</h6>
                                        <li><a href=\"salwars.html\">Salwars</a></li>
                                        <li><a href=\"sarees.html\">Sarees<span>New</span></a></li>
                                        <li><a href=\"products.html\"><i>Summer Store</i></a></li>
                                    </ul>
                                </div>
                                <div class=\"col-sm-3\">
                                    <ul class=\"multi-column-dropdown\">
                                        <h6>Materiel sport</h6>
                                        <li><a href=\"sandals.html\">Flats</a></li>
                                        <li><a href=\"sandals.html\">Sandals</a></li>
                                        <li><a href=\"sandals.html\">Boots</a></li>
                                        <li><a href=\"sandals.html\">Heels</a></li>
                                    </ul>
                                </div>
                                <div class=\"col-sm-3\">
                                    <ul class=\"multi-column-dropdown\">
                                        <h6>Materiel musculation</h6>
                                        <li><a href=\"{{ path('products') }}\">Dresses<span>New</span></a></li>
                                        <li><a href=\"sweaters.html\">Sweaters</a></li>
                                        <li><a href=\"skirts.html\">Shorts & Skirts</a></li>
                                        <li><a href=\"jeans.html\">Jeans</a></li>
                                        <li><a href=\"shirts.html\">Shirts & Tops<span>New</span></a></li>
                                    </ul>

                                <div class=\"clearfix\"></div>
                            </div>
                            </div>
                        </ul>
                    </li>
                    <li><a href=\"{{ path('about') }}\"{% block actAbout%}  {% endblock %}>A propos de nous</a></li>
                    <li><a href=\"{{ path('commande') }}\"{% block actCommande%}  {% endblock %}>Commandes</a></li>
                    <li><a href=\"{{ path('reclamation') }}\"{% block actRec %}  {% endblock %}>Reclamation</a></li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<!-- //header -->
{% endblock %}
{% block banner %}
<!-- banner -->
<div class=\"banner\" id=\"home1\">
    <div class=\"container\">
        <h3>fashions fade, <span>style is eternal</span></h3>
    </div>
</div>
<!-- //banner -->

<!-- banner-bottom -->
<div class=\"banner-bottom\">
    <div class=\"container\">
        <div class=\"col-md-5 wthree_banner_bottom_left\">
            <div class=\"video-img\">
                <a class=\"play-icon popup-with-zoom-anim\" href=\"#small-dialog\">
                    <span class=\"glyphicon glyphicon-expand\" aria-hidden=\"true\"></span>
                </a>
            </div>
            <!-- pop-up-box -->
            <link href=\"css/popuo-box.css\" rel=\"stylesheet\" type=\"text/css\" property=\"\" media=\"all\" />
            <script src=\"js/jquery.magnific-popup.js\" type=\"text/javascript\"></script>
            <!--//pop-up-box -->
            <div id=\"small-dialog\" class=\"mfp-hide\">
                <iframe src=\"https://player.vimeo.com/video/23259282?title=0&byline=0&portrait=0\"></iframe>
            </div>
            <script>
                \$(document).ready(function() {
                    \$('.popup-with-zoom-anim').magnificPopup({
                        type: 'inline',
                        fixedContentPos: false,
                        fixedBgPos: true,
                        overflowY: 'auto',
                        closeBtnInside: true,
                        preloader: false,
                        midClick: true,
                        removalDelay: 300,
                        mainClass: 'my-mfp-zoom-in'
                    });

                });
            </script>
        </div>
        <div class=\"col-md-7 wthree_banner_bottom_right\">
            <div class=\"bs-example bs-example-tabs\" role=\"tabpanel\" data-example-id=\"togglable-tabs\">
                <ul id=\"myTab\" class=\"nav nav-tabs\" role=\"tablist\">
                    <li role=\"presentation\" class=\"active\"><a href=\"#home\" id=\"home-tab\" role=\"tab\" data-toggle=\"tab\" aria-controls=\"home\">T-shirts</a></li>
                    <li role=\"presentation\"><a href=\"#skirts\" role=\"tab\" id=\"skirts-tab\" data-toggle=\"tab\" aria-controls=\"skirts\">Skirts</a></li>
                    <li role=\"presentation\"><a href=\"#watches\" role=\"tab\" id=\"watches-tab\" data-toggle=\"tab\" aria-controls=\"watches\">Watches</a></li>
                    <li role=\"presentation\"><a href=\"#sandals\" role=\"tab\" id=\"sandals-tab\" data-toggle=\"tab\" aria-controls=\"sandals\">Sandals</a></li>
                    <li role=\"presentation\"><a href=\"#jewellery\" role=\"tab\" id=\"jewellery-tab\" data-toggle=\"tab\" aria-controls=\"jewellery\">Jewellery</a></li>
                </ul>
                <div id=\"myTabContent\" class=\"tab-content\">
                    <div role=\"tabpanel\" class=\"tab-pane fade active in\" id=\"home\" aria-labelledby=\"home-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/4.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/7.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">T-Shirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/4.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/7.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">T-Shirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/4.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/7.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/5.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/6.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">T-Shirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                    <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"skirts\" aria-labelledby=\"skirts-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Skirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Skirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/10.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/8.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/9.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Skirt</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                    <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"watches\" aria-labelledby=\"watches-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal2\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Watch</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal2\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Watch</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/13.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/11.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/12.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal2\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Watch</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                    <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"sandals\" aria-labelledby=\"sandals-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Sandal</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Sandal</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/16.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/14.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/15.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal3\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Sandal</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                    <div role=\"tabpanel\" class=\"tab-pane fade\" id=\"jewellery\" aria-labelledby=\"jewellery-tab\">
                        <div class=\"agile_ecommerce_tabs\">
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal4\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Jewellery</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal4\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Jewellery</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"col-md-4 agile_ecommerce_tab_left\">
                                <div class=\"hs-wrapper\">
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/19.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/17.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/18.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal4\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Jewellery</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                    <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                            <div class=\"clearfix\"> </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--modal-video-->
            <div class=\"modal video-modal fade\" id=\"myModal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/20.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's shirt</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal1\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal1\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/63.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look black women's jeans</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal2\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal2\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/23.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Watch</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal3\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal3\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/24.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Sandal</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal4\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal4\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/22.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Necklace</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal5\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal5\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/35.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Jacket</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
            <div class=\"modal video-modal fade\" id=\"myModal6\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal6\">
                <div class=\"modal-dialog\" role=\"document\">
                    <div class=\"modal-content\">
                        <div class=\"modal-header\">
                            <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                        </div>
                        <section>
                            <div class=\"modal-body\">
                                <div class=\"col-md-5 modal_body_left\">
                                    <img src=\"images/39.jpg\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"col-md-7 modal_body_right\">
                                    <h4>a good look women's Long Skirt</h4>
                                    <p>Ut enim ad minim veniam, quis nostrud
                                        exercitation ullamco laboris nisi ut aliquip ex ea
                                        commodo consequat.Duis aute irure dolor in
                                        reprehenderit in voluptate velit esse cillum dolore
                                        eu fugiat nulla pariatur. Excepteur sint occaecat
                                        cupidatat non proident, sunt in culpa qui officia
                                        deserunt mollit anim id est laborum.</p>
                                    <div class=\"rating\">
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"rating-left\">
                                            <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                        </div>
                                        <div class=\"clearfix\"> </div>
                                    </div>
                                    <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                    </div>
                                    <h5>Color</h5>
                                    <div class=\"color-quality\">
                                        <ul>
                                            <li><a href=\"#\"><span></span>Red</a></li>
                                            <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                            <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                            <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"clearfix\"> </div>
    </div>
</div>
<!-- //banner-bottom -->

<!-- banner-bottom1 -->
<div class=\"banner-bottom1\">
    <div class=\"agileinfo_banner_bottom1_grids\">
        <div class=\"col-md-7 agileinfo_banner_bottom1_grid_left\">
            <h3>Grand Opening Event With flat<span>20% <i>Discount</i></span></h3>
            <a href=\"products.html\">Shop Now</a>
        </div>
        <div class=\"col-md-5 agileinfo_banner_bottom1_grid_right\">
            <h4>hot deal</h4>
            <div class=\"timer_wrap\">
                <div id=\"counter\"> </div>
            </div>
            <script src=\"js/jquery.countdown.js\"></script>
            <script src=\"js/script.js\"></script>
        </div>
        <div class=\"clearfix\"> </div>
    </div>
</div>
<!-- //banner-bottom1 -->
{% endblock %}


{% block body %}
<!-- special-deals -->
<div class=\"special-deals\">
    <div class=\"container\">
        <h2>Special Deals</h2>
        <div class=\"w3agile_special_deals_grids\">
            <div class=\"col-md-7 w3agile_special_deals_grid_left\">
                <div class=\"w3agile_special_deals_grid_left_grid\">
                    <img src=\"images/26.jpg\" alt=\" \" class=\"img-responsive\" />
                    <div class=\"w3agile_special_deals_grid_left_grid_pos1\">
                        <h5>30%<span>Off/-</span></h5>
                    </div>
                    <div class=\"w3agile_special_deals_grid_left_grid_pos\">
                        <h4>We Offer <span>Best Products</span></h4>
                    </div>
                </div>
                <div class=\"wmuSlider example1\">
                    <div class=\"wmuSliderWrapper\">
                        <article style=\"position: absolute; width: 100%; opacity: 0;\">
                            <div class=\"banner-wrap\">
                                <div class=\"w3agile_special_deals_grid_left_grid1\">
                                    <img src=\"images/1.png\" alt=\" \" class=\"img-responsive\" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Laura</h4>
                                </div>
                            </div>
                        </article>
                        <article style=\"position: absolute; width: 100%; opacity: 0;\">
                            <div class=\"banner-wrap\">
                                <div class=\"w3agile_special_deals_grid_left_grid1\">
                                    <img src=\"images/2.png\" alt=\" \" class=\"img-responsive\" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Michael</h4>
                                </div>
                            </div>
                        </article>
                        <article style=\"position: absolute; width: 100%; opacity: 0;\">
                            <div class=\"banner-wrap\">
                                <div class=\"w3agile_special_deals_grid_left_grid1\">
                                    <img src=\"images/3.png\" alt=\" \" class=\"img-responsive\" />
                                    <p>Quis autem vel eum iure reprehenderit qui in ea voluptate
                                        velit esse quam nihil molestiae consequatur, vel illum qui dolorem
                                        eum fugiat quo voluptas nulla pariatur</p>
                                    <h4>Rosy</h4>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
                <script src=\"js/jquery.wmuSlider.js\"></script>
                <script>
                    \$('.example1').wmuSlider();
                </script>
            </div>
            <div class=\"col-md-5 w3agile_special_deals_grid_right\">
                <img src=\"images/25.jpg\" alt=\" \" class=\"img-responsive\" />
                <div class=\"w3agile_special_deals_grid_right_pos\">
                    <h4>Women's <span>Special</span></h4>
                    <h5>save up <span>to</span> 30%</h5>
                </div>
            </div>
            <div class=\"clearfix\"> </div>
        </div>
    </div>
</div>
<!-- //special-deals -->
<!-- new-products -->
<div class=\"new-products\">
    <div class=\"container\">
        <h3>New Products</h3>
        <div class=\"agileinfo_new_products_grids\">
            <div class=\"col-md-3 agileinfo_new_products_grid\">
                <div class=\"agile_ecommerce_tab_left agileinfo_new_products_grid1\">
                    <div class=\"hs-wrapper hs-wrapper1\">
                        <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/29.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/29.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                        <div class=\"w3_hs_bottom w3_hs_bottom_sub\">
                            <ul>
                                <li>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href=\"single.html\">Skirts</a></h5>
                    <div class=\"simpleCart_shelfItem\">
                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                    </div>
                </div>
            </div>
            <div class=\"col-md-3 agileinfo_new_products_grid\">
                <div class=\"agile_ecommerce_tab_left agileinfo_new_products_grid1\">
                    <div class=\"hs-wrapper hs-wrapper1\">
                        <img src=\"images/31.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/32.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/33.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/34.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/31.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/32.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/33.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/34.jpg\" alt=\" \" class=\"img-responsive\" />
                        <div class=\"w3_hs_bottom w3_hs_bottom_sub\">
                            <ul>
                                <li>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal5\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href=\"single.html\">Jackets</a></h5>
                    <div class=\"simpleCart_shelfItem\">
                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                    </div>
                </div>
            </div>
            <div class=\"col-md-3 agileinfo_new_products_grid\">
                <div class=\"agile_ecommerce_tab_left agileinfo_new_products_grid1\">
                    <div class=\"hs-wrapper hs-wrapper1\">
                        <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                        <div class=\"w3_hs_bottom w3_hs_bottom_sub\">
                            <ul>
                                <li>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href=\"single.html\">Dresses</a></h5>
                    <div class=\"simpleCart_shelfItem\">
                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                    </div>
                </div>
            </div>
            <div class=\"col-md-3 agileinfo_new_products_grid\">
                <div class=\"agile_ecommerce_tab_left agileinfo_new_products_grid1\">
                    <div class=\"hs-wrapper hs-wrapper1\">
                        <img src=\"images/40.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/42.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/43.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/40.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/42.jpg\" alt=\" \" class=\"img-responsive\" />
                        <img src=\"images/43.jpg\" alt=\" \" class=\"img-responsive\" />
                        <div class=\"w3_hs_bottom w3_hs_bottom_sub\">
                            <ul>
                                <li>
                                    <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal1\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <h5><a href=\"single.html\">Jeans</a></h5>
                    <div class=\"simpleCart_shelfItem\">
                        <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                        <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                    </div>
                </div>
            </div>
            <div class=\"clearfix\"> </div>
        </div>
    </div>
</div>
<!-- //new-products -->
<!-- top-brands -->
<div class=\"top-brands\">
    <div class=\"container\">
        <h3>Top Brands</h3>
        <div class=\"sliderfig\">
            <ul id=\"flexiselDemo1\">
                <li>
                    <img src=\"images/4.png\" alt=\" \" class=\"img-responsive\" />
                </li>
                <li>
                    <img src=\"images/5.png\" alt=\" \" class=\"img-responsive\" />
                </li>
                <li>
                    <img src=\"images/6.png\" alt=\" \" class=\"img-responsive\" />
                </li>
                <li>
                    <img src=\"images/7.png\" alt=\" \" class=\"img-responsive\" />
                </li>
                <li>
                    <img src=\"images/46.jpg\" alt=\" \" class=\"img-responsive\" />
                </li>
            </ul>
        </div>
        <script type=\"text/javascript\">
            \$(window).load(function() {
                \$(\"#flexiselDemo1\").flexisel({
                    visibleItems: 4,
                    animationSpeed: 1000,
                    autoPlay: true,
                    autoPlaySpeed: 3000,
                    pauseOnHover: true,
                    enableResponsiveBreakpoints: true,
                    responsiveBreakpoints: {
                        portrait: {
                            changePoint:480,
                            visibleItems: 1
                        },
                        landscape: {
                            changePoint:640,
                            visibleItems:2
                        },
                        tablet: {
                            changePoint:768,
                            visibleItems: 3
                        }
                    }
                });

            });
        </script>
        <script type=\"text/javascript\" src=\"js/jquery.flexisel.js\"></script>
    </div>
</div>
<!-- //top-brands -->
<!-- newsletter -->
<div class=\"newsletter\">
    <div class=\"container\">
        <div class=\"col-md-6 w3agile_newsletter_left\">
            <h3>Newsletter</h3>
            <p>Excepteur sint occaecat cupidatat non proident, sunt.</p>
        </div>
        <div class=\"col-md-6 w3agile_newsletter_right\">
            <form action=\"#\" method=\"post\">
                <input type=\"email\" name=\"Email\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">
                <input type=\"submit\" value=\"\" />
            </form>
        </div>
        <div class=\"clearfix\"> </div>
    </div>
</div>
<!-- //newsletter -->
{% endblock %}
{% block footer %}
<!-- footer -->
<div class=\"footer\">
    <div class=\"container\">
        <div class=\"w3_footer_grids\">
            <div class=\"col-md-3 w3_footer_grid\">
                <h3>Contact</h3>
                <p>Duis aute irure dolor in reprehenderit in voluptate velit esse.</p>
                <ul class=\"address\">
                    <li><i class=\"glyphicon glyphicon-map-marker\" aria-hidden=\"true\"></i>1234k Avenue, 4th block, <span>New York City.</span></li>
                    <li><i class=\"glyphicon glyphicon-envelope\" aria-hidden=\"true\"></i><a href=\"mailto:info@example.com\">info@example.com</a></li>
                    <li><i class=\"glyphicon glyphicon-earphone\" aria-hidden=\"true\"></i>+1234 567 567</li>
                </ul>
            </div>
            <div class=\"col-md-3 w3_footer_grid\">
                <h3>Information</h3>
                <ul class=\"info\">
                    <li><a href=\"about.html\">About Us</a></li>
                    <li><a href=\"mail.html\">Contact Us</a></li>
                    <li><a href=\"short-codes.html\">Short Codes</a></li>
                    <li><a href=\"faq.html\">FAQ's</a></li>
                    <li><a href=\"products.html\">Special Products</a></li>
                </ul>
            </div>
            <div class=\"col-md-3 w3_footer_grid\">
                <h3>Category</h3>
                <ul class=\"info\">
                    <li><a href=\"dresses.html\">Dresses</a></li>
                    <li><a href=\"sweaters.html\">Sweaters</a></li>
                    <li><a href=\"shirts.html\">Shirts</a></li>
                    <li><a href=\"sarees.html\">Sarees</a></li>
                    <li><a href=\"skirts.html\">Shorts & Skirts</a></li>
                </ul>
            </div>
            <div class=\"col-md-3 w3_footer_grid\">
                <h3>Profile</h3>
                <ul class=\"info\">
                    <li><a href=\"products.html\">Summer Store</a></li>
                    <li><a href=\"checkout.html\">My Cart</a></li>
                </ul>
                <h4>Follow Us</h4>
                <div class=\"agileits_social_button\">
                    <ul>
                        <li><a href=\"#\" class=\"facebook\"> </a></li>
                        <li><a href=\"#\" class=\"twitter\"> </a></li>
                        <li><a href=\"#\" class=\"google\"> </a></li>
                        <li><a href=\"#\" class=\"pinterest\"> </a></li>
                    </ul>
                </div>
            </div>
            <div class=\"clearfix\"> </div>
        </div>
    </div>
    <div class=\"footer-copy\">
        <div class=\"footer-copy1\">
            <div class=\"footer-copy-pos\">
                <a href=\"#home1\" class=\"scroll\"><img src=\"images/arrow.png\" alt=\" \" class=\"img-responsive\" /></a>
            </div>
        </div>
        <div class=\"container\">
            <p>&copy; 2016 Women's Fashion. All rights reserved | Design by <a href=\"http://w3layouts.com/\">W3layouts</a></p>
        </div>
    </div>
</div>
<!-- //footer -->
{% endblock %}
</body>
</html>", "base.html.twig", "E:\\PIDEV_WEB\\Sport\\templates\\base.html.twig");
    }
}
