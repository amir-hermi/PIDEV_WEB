<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* panier/index.html.twig */
class __TwigTemplate_bfe8d0ce47efd517a427702aa231c62eb5bb8887dd64a9018fcd804059279a42 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'banner' => [$this, 'block_banner'],
            'ShowLogin' => [$this, 'block_ShowLogin'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "panier/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "panier/index.html.twig"));

        // line 2
        $context["prod"] = [];
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 3, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 5
            $context["prod"] = twig_array_merge((isset($context["prod"]) || array_key_exists("prod", $context) ? $context["prod"] : (function () { throw new RuntimeError('Variable "prod" does not exist.', 5, $this->source); })()), [0 => twig_get_attribute($this->env, $this->source, $context["i"], "id", [], "any", false, false, false, 5)]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 7
        $context["count"] = 0;
        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "panier/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 8
    public function block_banner($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        // line 9
        echo "
    <!-- banner -->
    <div class=\"banner10\" id=\"home1\">
        <div class=\"container\">
            <h2>Panier</h2>
        </div>
    </div>
    <!-- //banner -->

    <!-- breadcrumbs -->
    <div class=\"breadcrumb_dress\">
        <div class=\"container\">
            <ul>
                <li><a href=\"";
        // line 22
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i></li>
                <li>Panier</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 29
    public function block_ShowLogin($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 31
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 32
        echo "           <script type=\"application/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false);
               function hideURLbar(){ window.scrollTo(0,1); } </script>
           <!-- //for-mobile-apps -->
           <link href=\"css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/cs

           s\" media=\"all\" />
           <link href=\"css/fasthover.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <!-- js -->
           <script src=\"js/jquery.min.js\"></script>
           <!-- //js -->
           <!-- cart -->
           <script src=\"js/simpleCart.min.js\"></script>
           <!-- cart -->
           <!-- for bootstrap working -->
           <script type=\"text/javascript\" src=\"js/bootstrap-3.1.1.min.js\"></script>
           <!-- //for bootstrap working -->
           <link href='//fonts.googleapis.com/css?family=Glegoo:400,700' rel='stylesheet' type='text/css'>
           <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
           <!-- start-smooth-scrolling -->
           <script type=\"text/javascript\">
               jQuery(document).ready(function(\$) {
                   \$(\".scroll\").click(function(event){
                       event.preventDefault();
                       \$('html,body').animate({scrollTop:\$(this.hash).offset().top},1000);
                   });
               });
           </script>
           <!-- //end-smooth-scrolling -->

           <!-- checkout -->
           <div class=\"checkout\">
               <div class=\"container\">
                   <h3>Your shopping cart contains: <span>";
        // line 65
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 65, $this->source); })())), "html", null, true);
        echo " Products</span></h3>

                   <div class=\"checkout-right\">
                       <table class=\"timetable_sub\">
                           <thead>
                           <tr>
                               <th>SL No.</th>
                               <th>Product</th>
                               <th>Quantite</th>
                               <th>Product Name</th>
                               <th>Taille</th>
                               <th>Price</th>
                               <th>Action</th>
                           </tr>
                           </thead>
                           ";
        // line 80
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 80, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 81
            echo "                               ";
            $context["count"] = ((isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 81, $this->source); })()) + 1);
            // line 82
            echo "

                               <tr class=\"rem1\">
                               <td class=\"invert\">";
            // line 85
            echo twig_escape_filter($this->env, (isset($context["count"]) || array_key_exists("count", $context) ? $context["count"] : (function () { throw new RuntimeError('Variable "count" does not exist.', 85, $this->source); })()), "html", null, true);
            echo "</td>
                               <td class=\"invert-image\"><a href=\"";
            // line 86
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("detailleProduit", ["id" => twig_get_attribute($this->env, $this->source, $context["i"], "id", [], "any", false, false, false, 86)]), "html", null, true);
            echo "\"><img src=";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "image", [], "any", false, false, false, 86), "html", null, true);
            echo " alt=\"\" class=\"img-responsive\" /></a></td>
                               <td class=\"invert\">
                                   <div class=\"quantity\">
                                       ";
            // line 89
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "quantite", [], "any", false, false, false, 89), "html", null, true);
            echo "<br>

                                   </div>
                               </td>
                               <td class=\"invert\">
                                       ";
            // line 94
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "nom", [], "any", false, false, false, 94), "html", null, true);
            echo "
                               <td class=\"invert\">
                                       ";
            // line 96
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "taille", [], "any", false, false, false, 96), "html", null, true);
            echo "
                                   </td>
                               <td class=\"invert\">

                                       ";
            // line 100
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "prix", [], "any", false, false, false, 100), "html", null, true);
            echo "\$

                               </td>
                               <td class=\"invert\">
                                  <a href=\"";
            // line 104
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("removeP", ["id" => twig_get_attribute($this->env, $this->source, $context["i"], "id", [], "any", false, false, false, 104)]), "html", null, true);
            echo "\">
                                   <div class=\"rem\">
                                       <div class=\"close1\"> </div>
                                   </div>
                                  </a>
                               </td>
                           </tr>

                           ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 113
        echo "                       </table>
                   </div>
                   <div class=\"checkout-left\">
                       <div class=\"checkout-left-basket\">
                           <h4>Continue to basket</h4>
                           <ul>";
        // line 118
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 118, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 119
            echo "                               <li>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "nom", [], "any", false, false, false, 119), "html", null, true);
            echo " <i>- ";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "quantite", [], "any", false, false, false, 119), "html", null, true);
            echo "</i> <span>";
            echo twig_escape_filter($this->env, (twig_get_attribute($this->env, $this->source, $context["i"], "prix", [], "any", false, false, false, 119) * twig_get_attribute($this->env, $this->source, $context["i"], "quantite", [], "any", false, false, false, 119)), "html", null, true);
            echo ".00 DT</span></li>
                               ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 121
        echo "                               <li>Frait de livraison <i>-</i> <span>7.00DT</span></li>
                               <li>Total <i>-</i> <span>";
        // line 122
        echo twig_escape_filter($this->env, ((isset($context["total"]) || array_key_exists("total", $context) ? $context["total"] : (function () { throw new RuntimeError('Variable "total" does not exist.', 122, $this->source); })()) + 7.0), "html", null, true);
        echo ".00</span></li>
                           </ul>
                           <br>
                           <h4>Mode de payement</h4>
                           <select class=\"form-select\" aria-label=\"Default select example\">
                               <option value=\"1\">Espece</option>
                               <option value=\"2\">Carte bancaire</option>

                           </select>
                           <br><br>

                           <a href=\"";
        // line 133
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("panierToCommande", ["idClient" => 1]);
        echo "\" class=\"btn btn-success\"><span aria-hidden=\"true\"></span>Commander</a>
                       </div>
                       <div class=\"checkout-right-basket\">
                           <a href=\"";
        // line 136
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\"><span class=\"glyphicon glyphicon-menu-left\" aria-hidden=\"true\"></span>Continue Shopping</a>
<br><br>
                           ";
        // line 138
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["formP"]) || array_key_exists("formP", $context) ? $context["formP"] : (function () { throw new RuntimeError('Variable "formP" does not exist.', 138, $this->source); })()), 'form');
        echo "
                       </div>

                       <div class=\"clearfix\"> </div>
                   </div>
               </div>
           </div>
           <div class=\"w3l_related_products\">
               <div class=\"container\">
                   <h3>Related Products</h3>
                   <ul id=\"flexiselDemo2\">
                       <li>
                           <div class=\"w3l_related_products_grid\">
                               <div class=\"agile_ecommerce_tab_left dresses_grid\">
                                   <div class=\"hs-wrapper hs-wrapper3\">
                                       <img src=\"images/ss1.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss2.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss3.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss4.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss5.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss6.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss7.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss8.jpg\" alt=\" \" class=\"img-responsive\">
                                       <div class=\"w3_hs_bottom\">
                                           <div class=\"flex_ecommerce\">
                                               <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                           </div>
                                       </div>
                                   </div>
                                   <h5><a href=\"#\">Pink Flared Skirt</a></h5>
                                   <div class=\"simpleCart_shelfItem\">
                                       <p class=\"flexisel_ecommerce_cart\"><span>\$312</span> <i class=\"item_price\">\$212</i></p>
                                       <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                   </div>
                               </div>
                           </div>
                       </li>

                   </ul>
                   <script type=\"text/javascript\">
                       \$(window).load(function() {
                           \$(\"#flexiselDemo2\").flexisel({
                               visibleItems:4,
                               animationSpeed: 1000,
                               autoPlay: true,
                               autoPlaySpeed: 3000,
                               pauseOnHover: true,
                               enableResponsiveBreakpoints: true,
                               responsiveBreakpoints: {
                                   portrait: {
                                       changePoint:480,
                                       visibleItems: 1
                                   },
                                   landscape: {
                                       changePoint:640,
                                       visibleItems:2
                                   },
                                   tablet: {
                                       changePoint:768,
                                       visibleItems: 3
                                   }
                               }
                           });

                       });
                   </script>
                   <script type=\"text/javascript\" src=\"js/jquery.flexisel.js\"></script>
               </div>
           </div>
           <div class=\"modal video-modal fade\" id=\"myModal6\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal6\">
               <div class=\"modal-dialog\" role=\"document\">
                   <div class=\"modal-content\">
                       <div class=\"modal-header\">
                           <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                       </div>
                       <section>
                           <div class=\"modal-body\">
                               <div class=\"col-md-5 modal_body_left\">
                                   <img src=\"images/39.jpg\" alt=\" \" class=\"img-responsive\" />
                               </div>
                               <div class=\"col-md-7 modal_body_right\">
                                   <h4>a good look women's Long Skirt</h4>
                                   <p>Ut enim ad minim veniam, quis nostrud
                                       exercitation ullamco laboris nisi ut aliquip ex ea
                                       commodo consequat.Duis aute irure dolor in
                                       reprehenderit in voluptate velit esse cillum dolore
                                       eu fugiat nulla pariatur. Excepteur sint occaecat
                                       cupidatat non proident, sunt in culpa qui officia
                                       deserunt mollit anim id est laborum.</p>
                                   <div class=\"rating\">
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"clearfix\"> </div>
                                   </div>
                                   <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                       <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                       <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                   </div>
                                   <h5>Color</h5>
                                   <div class=\"color-quality\">
                                       <ul>
                                           <li><a href=\"#\"><span></span>Red</a></li>
                                           <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                           <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                           <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                       </ul>
                                   </div>
                               </div>
                               <div class=\"clearfix\"> </div>
                           </div>
                       </section>
                   </div>
               </div>
           </div>
           <!-- //checkout -->
       ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "panier/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  316 => 138,  311 => 136,  305 => 133,  291 => 122,  288 => 121,  275 => 119,  271 => 118,  264 => 113,  249 => 104,  242 => 100,  235 => 96,  230 => 94,  222 => 89,  214 => 86,  210 => 85,  205 => 82,  202 => 81,  198 => 80,  180 => 65,  145 => 32,  135 => 31,  117 => 29,  100 => 22,  85 => 9,  75 => 8,  64 => 1,  62 => 7,  56 => 5,  52 => 3,  50 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% set prod = {} %}
{% for i in data %}

        {%  set prod = prod|merge([i.id]) %}
    {% endfor %}
{% set count=0 %}
{% block banner %}

    <!-- banner -->
    <div class=\"banner10\" id=\"home1\">
        <div class=\"container\">
            <h2>Panier</h2>
        </div>
    </div>
    <!-- //banner -->

    <!-- breadcrumbs -->
    <div class=\"breadcrumb_dress\">
        <div class=\"container\">
            <ul>
                <li><a href=\"{{ path('home') }}\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i></li>
                <li>Panier</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->
{% endblock %}
{% block ShowLogin %}
{% endblock %}
       {% block body %}
           <script type=\"application/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false);
               function hideURLbar(){ window.scrollTo(0,1); } </script>
           <!-- //for-mobile-apps -->
           <link href=\"css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/cs

           s\" media=\"all\" />
           <link href=\"css/fasthover.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <!-- js -->
           <script src=\"js/jquery.min.js\"></script>
           <!-- //js -->
           <!-- cart -->
           <script src=\"js/simpleCart.min.js\"></script>
           <!-- cart -->
           <!-- for bootstrap working -->
           <script type=\"text/javascript\" src=\"js/bootstrap-3.1.1.min.js\"></script>
           <!-- //for bootstrap working -->
           <link href='//fonts.googleapis.com/css?family=Glegoo:400,700' rel='stylesheet' type='text/css'>
           <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
           <!-- start-smooth-scrolling -->
           <script type=\"text/javascript\">
               jQuery(document).ready(function(\$) {
                   \$(\".scroll\").click(function(event){
                       event.preventDefault();
                       \$('html,body').animate({scrollTop:\$(this.hash).offset().top},1000);
                   });
               });
           </script>
           <!-- //end-smooth-scrolling -->

           <!-- checkout -->
           <div class=\"checkout\">
               <div class=\"container\">
                   <h3>Your shopping cart contains: <span>{{ data|length}} Products</span></h3>

                   <div class=\"checkout-right\">
                       <table class=\"timetable_sub\">
                           <thead>
                           <tr>
                               <th>SL No.</th>
                               <th>Product</th>
                               <th>Quantite</th>
                               <th>Product Name</th>
                               <th>Taille</th>
                               <th>Price</th>
                               <th>Action</th>
                           </tr>
                           </thead>
                           {% for i in data %}
                               {% set count=count+1 %}


                               <tr class=\"rem1\">
                               <td class=\"invert\">{{ count }}</td>
                               <td class=\"invert-image\"><a href=\"{{ path('detailleProduit',{id : i.id}) }}\"><img src={{ i.image}} alt=\"\" class=\"img-responsive\" /></a></td>
                               <td class=\"invert\">
                                   <div class=\"quantity\">
                                       {{ i.quantite }}<br>

                                   </div>
                               </td>
                               <td class=\"invert\">
                                       {{ i.nom}}
                               <td class=\"invert\">
                                       {{ i.taille}}
                                   </td>
                               <td class=\"invert\">

                                       {{ i.prix }}\$

                               </td>
                               <td class=\"invert\">
                                  <a href=\"{{ path('removeP',{id : i.id}) }}\">
                                   <div class=\"rem\">
                                       <div class=\"close1\"> </div>
                                   </div>
                                  </a>
                               </td>
                           </tr>

                           {% endfor %}
                       </table>
                   </div>
                   <div class=\"checkout-left\">
                       <div class=\"checkout-left-basket\">
                           <h4>Continue to basket</h4>
                           <ul>{% for i in data %}
                               <li>{{ i.nom }} <i>- {{ i.quantite }}</i> <span>{{i.prix * i.quantite}}.00 DT</span></li>
                               {% endfor %}
                               <li>Frait de livraison <i>-</i> <span>7.00DT</span></li>
                               <li>Total <i>-</i> <span>{{ total + 7.00 }}.00</span></li>
                           </ul>
                           <br>
                           <h4>Mode de payement</h4>
                           <select class=\"form-select\" aria-label=\"Default select example\">
                               <option value=\"1\">Espece</option>
                               <option value=\"2\">Carte bancaire</option>

                           </select>
                           <br><br>

                           <a href=\"{{ path('panierToCommande',{ idClient:1  }) }}\" class=\"btn btn-success\"><span aria-hidden=\"true\"></span>Commander</a>
                       </div>
                       <div class=\"checkout-right-basket\">
                           <a href=\"{{ path('products') }}\"><span class=\"glyphicon glyphicon-menu-left\" aria-hidden=\"true\"></span>Continue Shopping</a>
<br><br>
                           {{ form(formP) }}
                       </div>

                       <div class=\"clearfix\"> </div>
                   </div>
               </div>
           </div>
           <div class=\"w3l_related_products\">
               <div class=\"container\">
                   <h3>Related Products</h3>
                   <ul id=\"flexiselDemo2\">
                       <li>
                           <div class=\"w3l_related_products_grid\">
                               <div class=\"agile_ecommerce_tab_left dresses_grid\">
                                   <div class=\"hs-wrapper hs-wrapper3\">
                                       <img src=\"images/ss1.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss2.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss3.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss4.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss5.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss6.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss7.jpg\" alt=\" \" class=\"img-responsive\">
                                       <img src=\"images/ss8.jpg\" alt=\" \" class=\"img-responsive\">
                                       <div class=\"w3_hs_bottom\">
                                           <div class=\"flex_ecommerce\">
                                               <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                           </div>
                                       </div>
                                   </div>
                                   <h5><a href=\"#\">Pink Flared Skirt</a></h5>
                                   <div class=\"simpleCart_shelfItem\">
                                       <p class=\"flexisel_ecommerce_cart\"><span>\$312</span> <i class=\"item_price\">\$212</i></p>
                                       <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                   </div>
                               </div>
                           </div>
                       </li>

                   </ul>
                   <script type=\"text/javascript\">
                       \$(window).load(function() {
                           \$(\"#flexiselDemo2\").flexisel({
                               visibleItems:4,
                               animationSpeed: 1000,
                               autoPlay: true,
                               autoPlaySpeed: 3000,
                               pauseOnHover: true,
                               enableResponsiveBreakpoints: true,
                               responsiveBreakpoints: {
                                   portrait: {
                                       changePoint:480,
                                       visibleItems: 1
                                   },
                                   landscape: {
                                       changePoint:640,
                                       visibleItems:2
                                   },
                                   tablet: {
                                       changePoint:768,
                                       visibleItems: 3
                                   }
                               }
                           });

                       });
                   </script>
                   <script type=\"text/javascript\" src=\"js/jquery.flexisel.js\"></script>
               </div>
           </div>
           <div class=\"modal video-modal fade\" id=\"myModal6\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal6\">
               <div class=\"modal-dialog\" role=\"document\">
                   <div class=\"modal-content\">
                       <div class=\"modal-header\">
                           <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                       </div>
                       <section>
                           <div class=\"modal-body\">
                               <div class=\"col-md-5 modal_body_left\">
                                   <img src=\"images/39.jpg\" alt=\" \" class=\"img-responsive\" />
                               </div>
                               <div class=\"col-md-7 modal_body_right\">
                                   <h4>a good look women's Long Skirt</h4>
                                   <p>Ut enim ad minim veniam, quis nostrud
                                       exercitation ullamco laboris nisi ut aliquip ex ea
                                       commodo consequat.Duis aute irure dolor in
                                       reprehenderit in voluptate velit esse cillum dolore
                                       eu fugiat nulla pariatur. Excepteur sint occaecat
                                       cupidatat non proident, sunt in culpa qui officia
                                       deserunt mollit anim id est laborum.</p>
                                   <div class=\"rating\">
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"clearfix\"> </div>
                                   </div>
                                   <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                       <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                       <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                   </div>
                                   <h5>Color</h5>
                                   <div class=\"color-quality\">
                                       <ul>
                                           <li><a href=\"#\"><span></span>Red</a></li>
                                           <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                           <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                           <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                       </ul>
                                   </div>
                               </div>
                               <div class=\"clearfix\"> </div>
                           </div>
                       </section>
                   </div>
               </div>
           </div>
           <!-- //checkout -->
       {% endblock %}












", "panier/index.html.twig", "E:\\PIDEV_WEB\\Sport\\templates\\panier\\index.html.twig");
    }
}
