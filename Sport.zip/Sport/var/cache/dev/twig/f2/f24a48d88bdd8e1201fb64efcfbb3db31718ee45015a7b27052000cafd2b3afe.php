<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* panier/produitDetaille.html.twig */
class __TwigTemplate_f0b7a02788b13a4f5f59eb1774063b3ca581bf41949606604a2d4e41fd5232b8 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'ShowLogin' => [$this, 'block_ShowLogin'],
            'banner' => [$this, 'block_banner'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "panier/produitDetaille.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "panier/produitDetaille.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "panier/produitDetaille.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_ShowLogin($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_banner($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        // line 7
        echo "
<!-- banner -->
<div class=\"banner10\" id=\"home1\">
    <div class=\"container\">
        <h2>Detaille</h2>
    </div>
</div>
<!-- //banner -->

<!-- breadcrumbs -->
<div class=\"breadcrumb_dress\">
    <div class=\"container\">
        <ul>
            <li><a href=\"";
        // line 20
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i>
                <a href=\"";
        // line 21
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("panier");
        echo "\"> Panier</a> <i>/</i>
            </li>
            <li>Detaille</li>
        </ul>
    </div>
</div>
<!-- //breadcrumbs -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 29
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 30
        echo "        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                </div>
                <section>

                    <div class=\"modal-body\">
                        <div class=\"col-md-5 modal_body_left\">
                            <img src=\"";
        // line 39
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 39, $this->source); })()), "image", [], "any", false, false, false, 39), "html", null, true);
        echo "\" alt=\"\" class=\"img-responsive\" />
                        </div>
                        <div class=\"col-md-7 modal_body_right\">
                            <h4>";
        // line 42
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["produit"]) || array_key_exists("produit", $context) ? $context["produit"] : (function () { throw new RuntimeError('Variable "produit" does not exist.', 42, $this->source); })()), "nom", [], "any", false, false, false, 42), "html", null, true);
        echo "</h4>
                            <p>
                                jbsk xjsbnxjksb xsjbs xsjbsx xjsbkhsnklqs qbskqjbs qksbqs q
                            </p>
                            <div class=\"rating\">
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                            <div>
                                ";
        // line 65
        echo         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock((isset($context["form"]) || array_key_exists("form", $context) ? $context["form"] : (function () { throw new RuntimeError('Variable "form" does not exist.', 65, $this->source); })()), 'form');
        echo "
                            </div>
                            <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                <p><span> </span> <i class=\"item_price\"> </i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                            <h5>Color</h5>
                            <div class=\"color-quality\">
                                <ul>
                                    <li><a href=\"#\"><span></span>Red</a></li>
                                    <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                    <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                    <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                </section>
            </div>
        </div>

";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "panier/produitDetaille.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  178 => 65,  152 => 42,  146 => 39,  135 => 30,  125 => 29,  107 => 21,  103 => 20,  88 => 7,  78 => 6,  60 => 2,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block ShowLogin %}
{% endblock %}


{% block banner %}

<!-- banner -->
<div class=\"banner10\" id=\"home1\">
    <div class=\"container\">
        <h2>Detaille</h2>
    </div>
</div>
<!-- //banner -->

<!-- breadcrumbs -->
<div class=\"breadcrumb_dress\">
    <div class=\"container\">
        <ul>
            <li><a href=\"{{ path('home') }}\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i>
                <a href=\"{{ path('panier') }}\"> Panier</a> <i>/</i>
            </li>
            <li>Detaille</li>
        </ul>
    </div>
</div>
<!-- //breadcrumbs -->
{% endblock %}
{% block body %}
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                </div>
                <section>

                    <div class=\"modal-body\">
                        <div class=\"col-md-5 modal_body_left\">
                            <img src=\"{{ produit.image }}\" alt=\"\" class=\"img-responsive\" />
                        </div>
                        <div class=\"col-md-7 modal_body_right\">
                            <h4>{{ produit.nom}}</h4>
                            <p>
                                jbsk xjsbnxjksb xsjbs xsjbsx xjsbkhsnklqs qbskqjbs qksbqs q
                            </p>
                            <div class=\"rating\">
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                            <div>
                                {{ form(form) }}
                            </div>
                            <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                <p><span> </span> <i class=\"item_price\"> </i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                            <h5>Color</h5>
                            <div class=\"color-quality\">
                                <ul>
                                    <li><a href=\"#\"><span></span>Red</a></li>
                                    <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                    <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                    <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                </section>
            </div>
        </div>

{% endblock %}
", "panier/produitDetaille.html.twig", "E:\\PIDEV_WEB\\Sport\\templates\\panier\\produitDetaille.html.twig");
    }
}
