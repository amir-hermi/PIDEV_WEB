<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* commande/index.html.twig */
class __TwigTemplate_d853229f009575f5214f231ff11402530cf6b67ffdbc6f324cd8908dc94531fc extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'actCommande' => [$this, 'block_actCommande'],
            'banner' => [$this, 'block_banner'],
            'ShowLogin' => [$this, 'block_ShowLogin'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "commande/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "commande/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "commande/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 2
    public function block_actCommande($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actCommande"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actCommande"));

        echo " class=\"act\" ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 3
    public function block_banner($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        // line 4
        echo "    <!-- banner -->
    <div class=\"banner10\" id=\"home1\">
        <div class=\"container\">
            <h2>Commandes</h2>
        </div>
    </div>
    <!-- //banner -->

    <!-- breadcrumbs -->
    <div class=\"breadcrumb_dress\">
        <div class=\"container\">
            <ul>
                <li><a href=\"";
        // line 16
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i></li>
                <li>Commandes</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 23
    public function block_ShowLogin($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 25
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 26
        echo "           <script type=\"application/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false);
               function hideURLbar(){ window.scrollTo(0,1); } </script>
           <!-- //for-mobile-apps -->
           <link href=\"css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <link href=\"css/fasthover.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <!-- js -->
           <script src=\"js/jquery.min.js\"></script>
           <!-- //js -->
           <!-- cart -->
           <script src=\"js/simpleCart.min.js\"></script>
           <!-- cart -->
           <!-- for bootstrap working -->
           <script type=\"text/javascript\" src=\"js/bootstrap-3.1.1.min.js\"></script>
           <!-- //for bootstrap working -->
           <link href='//fonts.googleapis.com/css?family=Glegoo:400,700' rel='stylesheet' type='text/css'>
           <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
           <!-- start-smooth-scrolling -->
           <script type=\"text/javascript\">
               jQuery(document).ready(function(\$) {
                   \$(\".scroll\").click(function(event){
                       event.preventDefault();
                       \$('html,body').animate({scrollTop:\$(this.hash).offset().top},1000);
                   });
               });
           </script>
           <!-- //end-smooth-scrolling -->
           <!-- checkout -->
           <div class=\"checkout\">
               <div class=\"container\">

                   <h3>Your Orders : <span> ";
        // line 57
        echo twig_escape_filter($this->env, twig_length_filter($this->env, (isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 57, $this->source); })())), "html", null, true);
        echo " Orders</span></h3>

                   <div class=\"checkout-right\">
                       <table class=\"timetable_sub\">
                           <thead>
                           <tr>
                               <th>REF</th>
                               <th>Liste des produits</th>
                               <th>Montant</th>
                               <th>Date de creation</th>
                               <th>Etat de livraison</th>
                               <th>Remove</th>
                           </tr>
                           </thead>

                           ";
        // line 72
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 72, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 73
            echo "                           <tr class=\"rem1\">
                               <td class=\"invert\">";
            // line 74
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "reference", [], "any", false, false, false, 74), "html", null, true);
            echo "</td>
                               <td class=\"invert\">
                                   ";
            // line 76
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["i"], "getCommandeProduits", [], "method", false, false, false, 76), "toArray", [], "method", false, false, false, 76));
            foreach ($context['_seq'] as $context["_key"] => $context["a"]) {
                // line 77
                echo "                                  <b>Nom</b> : ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["a"], "getProduit", [], "method", false, false, false, 77), "nom", [], "any", false, false, false, 77), "html", null, true);
                echo " , <b>Quantite </b> : ";
                echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["a"], "quantiteProduit", [], "any", false, false, false, 77), "html", null, true);
                echo " <br>
                                   ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['a'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 79
            echo "                               </td>
                               <td class=\"invert\">
                                   <div class=\"quantity\">
                                       ";
            // line 82
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "montant", [], "any", false, false, false, 82), "html", null, true);
            echo "DT
                                   </div>
                               </td>
                               <td class=\"invert\"> ";
            // line 85
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["i"], "getDateCreation", [], "method", false, false, false, 85), "format", [0 => "j-m-y"], "method", false, false, false, 85), "html", null, true);
            echo "</td>
                               <td class=\"invert\">";
            // line 86
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "status", [], "any", false, false, false, 86), "html", null, true);
            echo "</td>
                               <td class=\"invert\">
                                   <div class=\"rem\">
                                       <a href=\"";
            // line 89
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("commandeDelete", ["id" => twig_get_attribute($this->env, $this->source, $context["i"], "id", [], "any", false, false, false, 89)]), "html", null, true);
            echo "\">
                                       <div class=\"close1\"> </div>
                                       </a>
                                   </div>

                               </td>
                           </tr>
                           ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 97
        echo "
                       </table>




               </div>
           </div>

           <div class=\"modal video-modal fade\" id=\"myModal6\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal6\">
               <div class=\"modal-dialog\" role=\"document\">
                   <div class=\"modal-content\">
                       <div class=\"modal-header\">
                           <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                       </div>
                       <section>
                           <div class=\"modal-body\">
                               <div class=\"col-md-5 modal_body_left\">
                                   <img src=\"images/39.jpg\" alt=\" \" class=\"img-responsive\" />
                               </div>
                               <div class=\"col-md-7 modal_body_right\">
                                   <h4>a good look women's Long Skirt</h4>
                                   <p>Ut enim ad minim veniam, quis nostrud
                                       exercitation ullamco laboris nisi ut aliquip ex ea
                                       commodo consequat.Duis aute irure dolor in
                                       reprehenderit in voluptate velit esse cillum dolore
                                       eu fugiat nulla pariatur. Excepteur sint occaecat
                                       cupidatat non proident, sunt in culpa qui officia
                                       deserunt mollit anim id est laborum.</p>
                                   <div class=\"rating\">
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"clearfix\"> </div>
                                   </div>
                                   <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                       <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                       <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                   </div>
                                   <h5>Color</h5>
                                   <div class=\"color-quality\">
                                       <ul>
                                           <li><a href=\"#\"><span></span>Red</a></li>
                                           <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                           <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                           <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                       </ul>
                                   </div>
                               </div>
                               <div class=\"clearfix\"> </div>
                           </div>
                       </section>
                   </div>
               </div>
           </div>
           <!-- //checkout -->
       ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "commande/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  262 => 97,  248 => 89,  242 => 86,  238 => 85,  232 => 82,  227 => 79,  216 => 77,  212 => 76,  207 => 74,  204 => 73,  200 => 72,  182 => 57,  149 => 26,  139 => 25,  121 => 23,  104 => 16,  90 => 4,  80 => 3,  61 => 2,  38 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}
{% block actCommande%} class=\"act\" {% endblock %}
{% block banner %}
    <!-- banner -->
    <div class=\"banner10\" id=\"home1\">
        <div class=\"container\">
            <h2>Commandes</h2>
        </div>
    </div>
    <!-- //banner -->

    <!-- breadcrumbs -->
    <div class=\"breadcrumb_dress\">
        <div class=\"container\">
            <ul>
                <li><a href=\"{{ path('home') }}\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i></li>
                <li>Commandes</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->
{% endblock %}
{% block ShowLogin %}
{% endblock %}
       {% block body %}
           <script type=\"application/x-javascript\"> addEventListener(\"load\", function() { setTimeout(hideURLbar, 0); }, false);
               function hideURLbar(){ window.scrollTo(0,1); } </script>
           <!-- //for-mobile-apps -->
           <link href=\"css/bootstrap.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <link href=\"css/style.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <link href=\"css/fasthover.css\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
           <!-- js -->
           <script src=\"js/jquery.min.js\"></script>
           <!-- //js -->
           <!-- cart -->
           <script src=\"js/simpleCart.min.js\"></script>
           <!-- cart -->
           <!-- for bootstrap working -->
           <script type=\"text/javascript\" src=\"js/bootstrap-3.1.1.min.js\"></script>
           <!-- //for bootstrap working -->
           <link href='//fonts.googleapis.com/css?family=Glegoo:400,700' rel='stylesheet' type='text/css'>
           <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
           <!-- start-smooth-scrolling -->
           <script type=\"text/javascript\">
               jQuery(document).ready(function(\$) {
                   \$(\".scroll\").click(function(event){
                       event.preventDefault();
                       \$('html,body').animate({scrollTop:\$(this.hash).offset().top},1000);
                   });
               });
           </script>
           <!-- //end-smooth-scrolling -->
           <!-- checkout -->
           <div class=\"checkout\">
               <div class=\"container\">

                   <h3>Your Orders : <span> {{ data|length}} Orders</span></h3>

                   <div class=\"checkout-right\">
                       <table class=\"timetable_sub\">
                           <thead>
                           <tr>
                               <th>REF</th>
                               <th>Liste des produits</th>
                               <th>Montant</th>
                               <th>Date de creation</th>
                               <th>Etat de livraison</th>
                               <th>Remove</th>
                           </tr>
                           </thead>

                           {% for i in data %}
                           <tr class=\"rem1\">
                               <td class=\"invert\">{{ i.reference }}</td>
                               <td class=\"invert\">
                                   {% for a in  i.getCommandeProduits().toArray() %}
                                  <b>Nom</b> : {{ a.getProduit().nom}} , <b>Quantite </b> : {{ a.quantiteProduit }} <br>
                                   {% endfor %}
                               </td>
                               <td class=\"invert\">
                                   <div class=\"quantity\">
                                       {{ i.montant }}DT
                                   </div>
                               </td>
                               <td class=\"invert\"> {{ i.getDateCreation().format('j-m-y') }}</td>
                               <td class=\"invert\">{{ i.status }}</td>
                               <td class=\"invert\">
                                   <div class=\"rem\">
                                       <a href=\"{{ path('commandeDelete',{'id':i.id}) }}\">
                                       <div class=\"close1\"> </div>
                                       </a>
                                   </div>

                               </td>
                           </tr>
                           {% endfor %}

                       </table>




               </div>
           </div>

           <div class=\"modal video-modal fade\" id=\"myModal6\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal6\">
               <div class=\"modal-dialog\" role=\"document\">
                   <div class=\"modal-content\">
                       <div class=\"modal-header\">
                           <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                       </div>
                       <section>
                           <div class=\"modal-body\">
                               <div class=\"col-md-5 modal_body_left\">
                                   <img src=\"images/39.jpg\" alt=\" \" class=\"img-responsive\" />
                               </div>
                               <div class=\"col-md-7 modal_body_right\">
                                   <h4>a good look women's Long Skirt</h4>
                                   <p>Ut enim ad minim veniam, quis nostrud
                                       exercitation ullamco laboris nisi ut aliquip ex ea
                                       commodo consequat.Duis aute irure dolor in
                                       reprehenderit in voluptate velit esse cillum dolore
                                       eu fugiat nulla pariatur. Excepteur sint occaecat
                                       cupidatat non proident, sunt in culpa qui officia
                                       deserunt mollit anim id est laborum.</p>
                                   <div class=\"rating\">
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"rating-left\">
                                           <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                       </div>
                                       <div class=\"clearfix\"> </div>
                                   </div>
                                   <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                       <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                       <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                                   </div>
                                   <h5>Color</h5>
                                   <div class=\"color-quality\">
                                       <ul>
                                           <li><a href=\"#\"><span></span>Red</a></li>
                                           <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                           <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                           <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                       </ul>
                                   </div>
                               </div>
                               <div class=\"clearfix\"> </div>
                           </div>
                       </section>
                   </div>
               </div>
           </div>
           <!-- //checkout -->
       {% endblock %}












", "commande/index.html.twig", "E:\\PIDEV_WEB\\Sport\\templates\\commande\\index.html.twig");
    }
}
