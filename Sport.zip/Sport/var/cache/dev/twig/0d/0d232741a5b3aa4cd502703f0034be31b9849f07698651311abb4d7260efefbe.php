<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* products/index.html.twig */
class __TwigTemplate_68990a228f71191da36306be871beacab694d05b5bdc01ebd04e656a9a0ba1ac extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'actProduct' => [$this, 'block_actProduct'],
            'ShowLogin' => [$this, 'block_ShowLogin'],
            'banner' => [$this, 'block_banner'],
            'body' => [$this, 'block_body'],
            'listProd' => [$this, 'block_listProd'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "products/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "products/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "products/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello ProductsController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_actProduct($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actProduct"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actProduct"));

        echo " class=\"act\" ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_ShowLogin($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_banner($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        // line 8
        echo "    <!-- banner -->
    <div class=\"banner8\" id=\"home1\">
        <div class=\"container\">
            <h2>Women Cosmetics<span>up to</span> Flat 40% <i>Discount</i></h2>
        </div>
    </div>
    <!-- //banner -->
    <!-- breadcrumbs -->
    <div class=\"breadcrumb_dress\">
        <div class=\"container\">
            <ul>
                <li><a href=\"";
        // line 19
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i></li>
                <li>Produits</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 26
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 27
        echo "    <!-- dresses -->
    <div class=\"dresses\">
        <div class=\"container\">
            <div class=\"w3ls_dresses_grids\">
                <div class=\"col-md-4 w3ls_dresses_grid_left\">
                    <div class=\"w3ls_dresses_grid_left_grid\">
                        <h3>Catégories</h3>
                        <div class=\"w3ls_dresses_grid_left_grid_sub\">
                            <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
                                <div class=\"panel panel-default\">
                                    <div class=\"panel-heading\" role=\"tab\" id=\"headingOne\">
                                        <h4 class=\"panel-title asd\">
                                            <a class=\"pa_italic\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\" aria-expanded=\"true\" aria-controls=\"collapseOne\">
                                                <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span><i class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></i>Hommes
                                            </a>
                                        </h4>
                                    </div>
                                    <div id=\"collapseOne\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne\">
                                        <div class=\"panel-body panel_text\">
                                            <ul>
                                                <li><a href=\"";
        // line 47
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Dresses</a></li>
                                                <li><a href=\"";
        // line 48
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Sweaters</a></li>
                                                <li><a href=\"";
        // line 49
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Shorts & Skirts</a></li>
                                                <li><a href=\"";
        // line 50
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Jeans</a></li>
                                                <li><a href=\"";
        // line 51
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Shirts</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"panel panel-default\">
                                    <div class=\"panel-heading\" role=\"tab\" id=\"headingTwo\">
                                        <h4 class=\"panel-title asd\">
                                            <a class=\"pa_italic collapsed\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo\" aria-expanded=\"false\" aria-controls=\"collapseTwo\">
                                                <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span><i class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></i>Femmes
                                            </a>
                                        </h4>
                                    </div>
                                    <div id=\"collapseTwo\" class=\"panel-collapse collapse\" role=\"tabpanel\" aria-labelledby=\"headingTwo\">
                                        <div class=\"panel-body panel_text\">
                                            <ul>
                                                <li><a href=\"";
        // line 67
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Dresses</a></li>
                                                <li><a href=\"";
        // line 68
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Sweaters</a></li>
                                                <li><a href=\"";
        // line 69
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Shorts & Skirts</a></li>
                                                <li><a href=\"";
        // line 70
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Jeans</a></li>
                                                <li><a href=\"";
        // line 71
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Shirts</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=\"panel panel-default\">
                                <div class=\"panel-heading\" role=\"tab\" id=\"headingThree\">
                                    <h4 class=\"panel-title asd\">
                                        <a class=\"pa_italic\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree\" aria-expanded=\"true\" aria-controls=\"collapseThree\">
                                            <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span><i class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></i>Materiel sport
                                        </a>
                                    </h4>
                                </div>
                                <div id=\"collapseThree\" class=\"panel-collapse collapse \" role=\"tabpanel\" aria-labelledby=\"headingThree\">
                                    <div class=\"panel-body panel_text\">
                                        <ul>
                                            <li><a href=\"";
        // line 88
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Dresses</a></li>
                                            <li><a href=\"";
        // line 89
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Sweaters</a></li>
                                            <li><a href=\"";
        // line 90
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Shorts & Skirts</a></li>
                                            <li><a href=\"";
        // line 91
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Jeans</a></li>
                                            <li><a href=\"";
        // line 92
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Shirts</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class=\"panel panel-default\">
                                <div class=\"panel-heading\" role=\"tab\" id=\"headingFour\">
                                    <h4 class=\"panel-title asd\">
                                        <a class=\"pa_italic\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseFour\" aria-expanded=\"true\" aria-controls=\"collapseFour\">
                                            <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span><i class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></i>Materiel musculation
                                        </a>
                                    </h4>
                                </div>
                                <div id=\"collapseFour\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne\">
                                    <div class=\"panel-body panel_text\">
                                        <ul>
                                            <li><a href=\"";
        // line 108
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Dresses</a></li>
                                            <li><a href=\"";
        // line 109
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Sweaters</a></li>
                                            <li><a href=\"";
        // line 110
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Shorts & Skirts</a></li>
                                            <li><a href=\"";
        // line 111
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Jeans</a></li>
                                            <li><a href=\"";
        // line 112
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("products");
        echo "\">Shirts</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class=\"w3ls_dresses_grid_left_grid\">
                        <h3>Size</h3>
                        <div class=\"w3ls_dresses_grid_left_grid_sub\">
                            <div class=\"ecommerce_color ecommerce_size\">
                                <ul>
                                    <li><a href=\"#\">Medium</a></li>
                                    <li><a href=\"#\">Large</a></li>
                                    <li><a href=\"#\">Extra Large</a></li>
                                    <li><a href=\"#\">Small</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-md-8 w3ls_dresses_grid_right\">



";
        // line 139
        $this->displayBlock('listProd', $context, $blocks);
        // line 193
        echo "
                </div>
                <div class=\"clearfix\"> </div>
            </div>
        </div>
    </div>
    <div class=\"modal video-modal fade\" id=\"myModal9\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal9\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                </div>
                <section>
                    <div class=\"modal-body\">
                        <div class=\"col-md-5 modal_body_left\">
                            <img src=\"images/76.jpg\" alt=\" \" class=\"img-responsive\" />
                        </div>
                        <div class=\"col-md-7 modal_body_right\">
                            <h4>For Skin Care</h4>
                            <p>Ut enim ad minim veniam, quis nostrud
                                exercitation ullamco laboris nisi ut aliquip ex ea
                                commodo consequat.Duis aute irure dolor in
                                reprehenderit in voluptate velit esse cillum dolore
                                eu fugiat nulla pariatur. Excepteur sint occaecat
                                cupidatat non proident, sunt in culpa qui officia
                                deserunt mollit anim id est laborum.</p>
                            <div class=\"rating\">
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                            <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                            <h5>Color</h5>
                            <div class=\"color-quality\">
                                <ul>
                                    <li><a href=\"#\"><span></span>Red</a></li>
                                    <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                    <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                    <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class=\"modal video-modal fade\" id=\"myModal2\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal2\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                </div>
                <section>
                    <div class=\"modal-body\">
                        <div class=\"col-md-5 modal_body_left\">
                            <img src=\"images/23.jpg\" alt=\" \" class=\"img-responsive\" />
                        </div>
                        <div class=\"col-md-7 modal_body_right\">
                            <h4>a good look women's Watch</h4>
                            <p>Ut enim ad minim veniam, quis nostrud
                                exercitation ullamco laboris nisi ut aliquip ex ea
                                commodo consequat.Duis aute irure dolor in
                                reprehenderit in voluptate velit esse cillum dolore
                                eu fugiat nulla pariatur. Excepteur sint occaecat
                                cupidatat non proident, sunt in culpa qui officia
                                deserunt mollit anim id est laborum.</p>
                            <div class=\"rating\">
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                            <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                            <h5>Color</h5>
                            <div class=\"color-quality\">
                                <ul>
                                    <li><a href=\"#\"><span></span>Red</a></li>
                                    <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                    <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                    <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class=\"modal video-modal fade\" id=\"myModal4\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal4\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                </div>
                <section>
                    <div class=\"modal-body\">
                        <div class=\"col-md-5 modal_body_left\">
                            <img src=\"images/22.jpg\" alt=\" \" class=\"img-responsive\" />
                        </div>
                        <div class=\"col-md-7 modal_body_right\">
                            <h4>a good look women's Necklace</h4>
                            <p>Ut enim ad minim veniam, quis nostrud
                                exercitation ullamco laboris nisi ut aliquip ex ea
                                commodo consequat.Duis aute irure dolor in
                                reprehenderit in voluptate velit esse cillum dolore
                                eu fugiat nulla pariatur. Excepteur sint occaecat
                                cupidatat non proident, sunt in culpa qui officia
                                deserunt mollit anim id est laborum.</p>
                            <div class=\"rating\">
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                            <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                            <h5>Color</h5>
                            <div class=\"color-quality\">
                                <ul>
                                    <li><a href=\"#\"><span></span>Red</a></li>
                                    <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                    <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                    <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class=\"w3l_related_products\">
        <div class=\"container\">
            <h3>Related Products</h3>
            <ul id=\"flexiselDemo2\">
                <li>
                    <div class=\"w3l_related_products_grid\">
                        <div class=\"agile_ecommerce_tab_left dresses_grid\">
                            <div class=\"hs-wrapper hs-wrapper3\">
                                <img src=\"images/51.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <div class=\"w3_hs_bottom\">
                                    <div class=\"flex_ecommerce\">
                                        <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                    </div>
                                </div>
                            </div>
                            <h5><a href=\"single.html\">Long Purple Skirts</a></h5>
                            <div class=\"simpleCart_shelfItem\">
                                <p class=\"flexisel_ecommerce_cart\"><span>\$312</span> <i class=\"item_price\">\$212</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class=\"w3l_related_products_grid\">
                        <div class=\"agile_ecommerce_tab_left dresses_grid\">
                            <div class=\"hs-wrapper hs-wrapper3\">
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <div class=\"w3_hs_bottom\">
                                    <div class=\"flex_ecommerce\">
                                        <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                    </div>
                                </div>
                            </div>
                            <h5><a href=\"single.html\">Black Shorts</a></h5>
                            <div class=\"simpleCart_shelfItem\">
                                <p class=\"flexisel_ecommerce_cart\"><span>\$432</span> <i class=\"item_price\">\$323</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class=\"w3l_related_products_grid\">
                        <div class=\"agile_ecommerce_tab_left dresses_grid\">
                            <div class=\"hs-wrapper hs-wrapper3\">
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <div class=\"w3_hs_bottom\">
                                    <div class=\"flex_ecommerce\">
                                        <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                    </div>
                                </div>
                            </div>
                            <h5><a href=\"single.html\">White Skirts</a></h5>
                            <div class=\"simpleCart_shelfItem\">
                                <p class=\"flexisel_ecommerce_cart\"><span>\$323</span> <i class=\"item_price\">\$310</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class=\"w3l_related_products_grid\">
                        <div class=\"agile_ecommerce_tab_left dresses_grid\">
                            <div class=\"hs-wrapper hs-wrapper3\">
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <div class=\"w3_hs_bottom\">
                                    <div class=\"flex_ecommerce\">
                                        <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                    </div>
                                </div>
                            </div>
                            <h5><a href=\"single.html\">Long Skirts</a></h5>
                            <div class=\"simpleCart_shelfItem\">
                                <p class=\"flexisel_ecommerce_cart\"><span>\$256</span> <i class=\"item_price\">\$200</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
            <script type=\"text/javascript\">
                \$(window).load(function() {
                    \$(\"#flexiselDemo2\").flexisel({
                        visibleItems:4,
                        animationSpeed: 1000,
                        autoPlay: true,
                        autoPlaySpeed: 3000,
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: {
                            portrait: {
                                changePoint:480,
                                visibleItems: 1
                            },
                            landscape: {
                                changePoint:640,
                                visibleItems:2
                            },
                            tablet: {
                                changePoint:768,
                                visibleItems: 3
                            }
                        }
                    });

                });
            </script>
            <script type=\"text/javascript\" src=\"js/jquery.flexisel.js\"></script>
        </div>
    </div>
    <!-- //dresses -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 139
    public function block_listProd($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "listProd"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "listProd"));

        // line 140
        echo "                    <div class=\"w3ls_dresses_grid_right_grid2\">
                        <div class=\"w3ls_dresses_grid_right_grid2_left\">
                            <h3>Showing Results: 0-1</h3>
                        </div>
                        <div class=\"w3ls_dresses_grid_right_grid2_right\">
                            <select name=\"select_item\" class=\"select_item\">
                                <option selected=\"selected\">Default sorting</option>
                                <option>Sort by popularity</option>
                                <option>Sort by average rating</option>
                                <option>Sort by newness</option>
                                <option>Sort by price: low to high</option>
                                <option>Sort by price: high to low</option>
                            </select>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                    <div class=\"w3ls_dresses_grid_right_grid3\">

                        ";
        // line 158
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["data"]) || array_key_exists("data", $context) ? $context["data"] : (function () { throw new RuntimeError('Variable "data" does not exist.', 158, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
            // line 159
            echo "                        <div class=\"col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_dresses\">
                            <div class=\"agile_ecommerce_tab_left dresses_grid\">
                                <div class=\"hs-wrapper hs-wrapper2\">
                                    <img src=\"images/ado-banner.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p2.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p1.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p2.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p1.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p2.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom w3_hs_bottom_sub1\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal9\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Ideal Luminous Mousse</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>";
            // line 180
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["i"], "prix", [], "any", false, false, false, 180), "html", null, true);
            echo "</span> <i class=\"item_price\">\$200</i></p>
                                    <p><a href=\"";
            // line 181
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("panier");
            echo "\" class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                        </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 186
        echo "                        <div class=\"clearfix\"> </div>
                    </div>

                        <div class=\"clearfix\"> </div>
                    </div>

                ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "products/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  747 => 186,  736 => 181,  732 => 180,  709 => 159,  705 => 158,  685 => 140,  675 => 139,  345 => 193,  343 => 139,  313 => 112,  309 => 111,  305 => 110,  301 => 109,  297 => 108,  278 => 92,  274 => 91,  270 => 90,  266 => 89,  262 => 88,  242 => 71,  238 => 70,  234 => 69,  230 => 68,  226 => 67,  207 => 51,  203 => 50,  199 => 49,  195 => 48,  191 => 47,  169 => 27,  159 => 26,  142 => 19,  129 => 8,  119 => 7,  101 => 5,  82 => 4,  63 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello ProductsController!{% endblock %}
{% block actProduct%} class=\"act\" {% endblock %}
{% block ShowLogin %}
{% endblock %}
{% block banner %}
    <!-- banner -->
    <div class=\"banner8\" id=\"home1\">
        <div class=\"container\">
            <h2>Women Cosmetics<span>up to</span> Flat 40% <i>Discount</i></h2>
        </div>
    </div>
    <!-- //banner -->
    <!-- breadcrumbs -->
    <div class=\"breadcrumb_dress\">
        <div class=\"container\">
            <ul>
                <li><a href=\"{{ path('home') }}\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i></li>
                <li>Produits</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->
{% endblock %}
{% block body %}
    <!-- dresses -->
    <div class=\"dresses\">
        <div class=\"container\">
            <div class=\"w3ls_dresses_grids\">
                <div class=\"col-md-4 w3ls_dresses_grid_left\">
                    <div class=\"w3ls_dresses_grid_left_grid\">
                        <h3>Catégories</h3>
                        <div class=\"w3ls_dresses_grid_left_grid_sub\">
                            <div class=\"panel-group\" id=\"accordion\" role=\"tablist\" aria-multiselectable=\"true\">
                                <div class=\"panel panel-default\">
                                    <div class=\"panel-heading\" role=\"tab\" id=\"headingOne\">
                                        <h4 class=\"panel-title asd\">
                                            <a class=\"pa_italic\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseOne\" aria-expanded=\"true\" aria-controls=\"collapseOne\">
                                                <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span><i class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></i>Hommes
                                            </a>
                                        </h4>
                                    </div>
                                    <div id=\"collapseOne\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne\">
                                        <div class=\"panel-body panel_text\">
                                            <ul>
                                                <li><a href=\"{{ path('products') }}\">Dresses</a></li>
                                                <li><a href=\"{{ path('products') }}\">Sweaters</a></li>
                                                <li><a href=\"{{ path('products') }}\">Shorts & Skirts</a></li>
                                                <li><a href=\"{{ path('products') }}\">Jeans</a></li>
                                                <li><a href=\"{{ path('products') }}\">Shirts</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class=\"panel panel-default\">
                                    <div class=\"panel-heading\" role=\"tab\" id=\"headingTwo\">
                                        <h4 class=\"panel-title asd\">
                                            <a class=\"pa_italic collapsed\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseTwo\" aria-expanded=\"false\" aria-controls=\"collapseTwo\">
                                                <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span><i class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></i>Femmes
                                            </a>
                                        </h4>
                                    </div>
                                    <div id=\"collapseTwo\" class=\"panel-collapse collapse\" role=\"tabpanel\" aria-labelledby=\"headingTwo\">
                                        <div class=\"panel-body panel_text\">
                                            <ul>
                                                <li><a href=\"{{ path('products') }}\">Dresses</a></li>
                                                <li><a href=\"{{ path('products') }}\">Sweaters</a></li>
                                                <li><a href=\"{{ path('products') }}\">Shorts & Skirts</a></li>
                                                <li><a href=\"{{ path('products') }}\">Jeans</a></li>
                                                <li><a href=\"{{ path('products') }}\">Shirts</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class=\"panel panel-default\">
                                <div class=\"panel-heading\" role=\"tab\" id=\"headingThree\">
                                    <h4 class=\"panel-title asd\">
                                        <a class=\"pa_italic\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseThree\" aria-expanded=\"true\" aria-controls=\"collapseThree\">
                                            <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span><i class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></i>Materiel sport
                                        </a>
                                    </h4>
                                </div>
                                <div id=\"collapseThree\" class=\"panel-collapse collapse \" role=\"tabpanel\" aria-labelledby=\"headingThree\">
                                    <div class=\"panel-body panel_text\">
                                        <ul>
                                            <li><a href=\"{{ path('products') }}\">Dresses</a></li>
                                            <li><a href=\"{{ path('products') }}\">Sweaters</a></li>
                                            <li><a href=\"{{ path('products') }}\">Shorts & Skirts</a></li>
                                            <li><a href=\"{{ path('products') }}\">Jeans</a></li>
                                            <li><a href=\"{{ path('products') }}\">Shirts</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class=\"panel panel-default\">
                                <div class=\"panel-heading\" role=\"tab\" id=\"headingFour\">
                                    <h4 class=\"panel-title asd\">
                                        <a class=\"pa_italic\" role=\"button\" data-toggle=\"collapse\" data-parent=\"#accordion\" href=\"#collapseFour\" aria-expanded=\"true\" aria-controls=\"collapseFour\">
                                            <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span><i class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></i>Materiel musculation
                                        </a>
                                    </h4>
                                </div>
                                <div id=\"collapseFour\" class=\"panel-collapse collapse in\" role=\"tabpanel\" aria-labelledby=\"headingOne\">
                                    <div class=\"panel-body panel_text\">
                                        <ul>
                                            <li><a href=\"{{ path('products') }}\">Dresses</a></li>
                                            <li><a href=\"{{ path('products') }}\">Sweaters</a></li>
                                            <li><a href=\"{{ path('products') }}\">Shorts & Skirts</a></li>
                                            <li><a href=\"{{ path('products') }}\">Jeans</a></li>
                                            <li><a href=\"{{ path('products') }}\">Shirts</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <div class=\"w3ls_dresses_grid_left_grid\">
                        <h3>Size</h3>
                        <div class=\"w3ls_dresses_grid_left_grid_sub\">
                            <div class=\"ecommerce_color ecommerce_size\">
                                <ul>
                                    <li><a href=\"#\">Medium</a></li>
                                    <li><a href=\"#\">Large</a></li>
                                    <li><a href=\"#\">Extra Large</a></li>
                                    <li><a href=\"#\">Small</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"col-md-8 w3ls_dresses_grid_right\">



{% block listProd %}
                    <div class=\"w3ls_dresses_grid_right_grid2\">
                        <div class=\"w3ls_dresses_grid_right_grid2_left\">
                            <h3>Showing Results: 0-1</h3>
                        </div>
                        <div class=\"w3ls_dresses_grid_right_grid2_right\">
                            <select name=\"select_item\" class=\"select_item\">
                                <option selected=\"selected\">Default sorting</option>
                                <option>Sort by popularity</option>
                                <option>Sort by average rating</option>
                                <option>Sort by newness</option>
                                <option>Sort by price: low to high</option>
                                <option>Sort by price: high to low</option>
                            </select>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                    <div class=\"w3ls_dresses_grid_right_grid3\">

                        {% for i in data %}
                        <div class=\"col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_dresses\">
                            <div class=\"agile_ecommerce_tab_left dresses_grid\">
                                <div class=\"hs-wrapper hs-wrapper2\">
                                    <img src=\"images/ado-banner.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p2.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p1.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p2.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p1.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p3.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <img src=\"images/p2.jpg\" alt=\" \" class=\"img-responsive\" />
                                    <div class=\"w3_hs_bottom w3_hs_bottom_sub1\">
                                        <ul>
                                            <li>
                                                <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal9\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href=\"single.html\">Ideal Luminous Mousse</a></h5>
                                <div class=\"simpleCart_shelfItem\">
                                    <p><span>{{ i.prix }}</span> <i class=\"item_price\">\$200</i></p>
                                    <p><a href=\"{{ path('panier') }}\" class=\"item_add\" href=\"#\">Add to cart</a></p>
                                </div>
                            </div>
                        </div>
                        {% endfor %}
                        <div class=\"clearfix\"> </div>
                    </div>

                        <div class=\"clearfix\"> </div>
                    </div>

                {% endblock %}

                </div>
                <div class=\"clearfix\"> </div>
            </div>
        </div>
    </div>
    <div class=\"modal video-modal fade\" id=\"myModal9\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal9\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                </div>
                <section>
                    <div class=\"modal-body\">
                        <div class=\"col-md-5 modal_body_left\">
                            <img src=\"images/76.jpg\" alt=\" \" class=\"img-responsive\" />
                        </div>
                        <div class=\"col-md-7 modal_body_right\">
                            <h4>For Skin Care</h4>
                            <p>Ut enim ad minim veniam, quis nostrud
                                exercitation ullamco laboris nisi ut aliquip ex ea
                                commodo consequat.Duis aute irure dolor in
                                reprehenderit in voluptate velit esse cillum dolore
                                eu fugiat nulla pariatur. Excepteur sint occaecat
                                cupidatat non proident, sunt in culpa qui officia
                                deserunt mollit anim id est laborum.</p>
                            <div class=\"rating\">
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                            <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                            <h5>Color</h5>
                            <div class=\"color-quality\">
                                <ul>
                                    <li><a href=\"#\"><span></span>Red</a></li>
                                    <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                    <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                    <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class=\"modal video-modal fade\" id=\"myModal2\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal2\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                </div>
                <section>
                    <div class=\"modal-body\">
                        <div class=\"col-md-5 modal_body_left\">
                            <img src=\"images/23.jpg\" alt=\" \" class=\"img-responsive\" />
                        </div>
                        <div class=\"col-md-7 modal_body_right\">
                            <h4>a good look women's Watch</h4>
                            <p>Ut enim ad minim veniam, quis nostrud
                                exercitation ullamco laboris nisi ut aliquip ex ea
                                commodo consequat.Duis aute irure dolor in
                                reprehenderit in voluptate velit esse cillum dolore
                                eu fugiat nulla pariatur. Excepteur sint occaecat
                                cupidatat non proident, sunt in culpa qui officia
                                deserunt mollit anim id est laborum.</p>
                            <div class=\"rating\">
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                            <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                            <h5>Color</h5>
                            <div class=\"color-quality\">
                                <ul>
                                    <li><a href=\"#\"><span></span>Red</a></li>
                                    <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                    <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                    <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class=\"modal video-modal fade\" id=\"myModal4\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"myModal4\">
        <div class=\"modal-dialog\" role=\"document\">
            <div class=\"modal-content\">
                <div class=\"modal-header\">
                    <button type=\"button\" class=\"close\" data-dismiss=\"modal\" aria-label=\"Close\"><span aria-hidden=\"true\">&times;</span></button>
                </div>
                <section>
                    <div class=\"modal-body\">
                        <div class=\"col-md-5 modal_body_left\">
                            <img src=\"images/22.jpg\" alt=\" \" class=\"img-responsive\" />
                        </div>
                        <div class=\"col-md-7 modal_body_right\">
                            <h4>a good look women's Necklace</h4>
                            <p>Ut enim ad minim veniam, quis nostrud
                                exercitation ullamco laboris nisi ut aliquip ex ea
                                commodo consequat.Duis aute irure dolor in
                                reprehenderit in voluptate velit esse cillum dolore
                                eu fugiat nulla pariatur. Excepteur sint occaecat
                                cupidatat non proident, sunt in culpa qui officia
                                deserunt mollit anim id est laborum.</p>
                            <div class=\"rating\">
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star-.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"rating-left\">
                                    <img src=\"images/star.png\" alt=\" \" class=\"img-responsive\" />
                                </div>
                                <div class=\"clearfix\"> </div>
                            </div>
                            <div class=\"modal_body_right_cart simpleCart_shelfItem\">
                                <p><span>\$320</span> <i class=\"item_price\">\$250</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                            <h5>Color</h5>
                            <div class=\"color-quality\">
                                <ul>
                                    <li><a href=\"#\"><span></span>Red</a></li>
                                    <li><a href=\"#\" class=\"brown\"><span></span>Yellow</a></li>
                                    <li><a href=\"#\" class=\"purple\"><span></span>Purple</a></li>
                                    <li><a href=\"#\" class=\"gray\"><span></span>Violet</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class=\"clearfix\"> </div>
                    </div>
                </section>
            </div>
        </div>
    </div>
    <div class=\"w3l_related_products\">
        <div class=\"container\">
            <h3>Related Products</h3>
            <ul id=\"flexiselDemo2\">
                <li>
                    <div class=\"w3l_related_products_grid\">
                        <div class=\"agile_ecommerce_tab_left dresses_grid\">
                            <div class=\"hs-wrapper hs-wrapper3\">
                                <img src=\"images/51.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <div class=\"w3_hs_bottom\">
                                    <div class=\"flex_ecommerce\">
                                        <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                    </div>
                                </div>
                            </div>
                            <h5><a href=\"single.html\">Long Purple Skirts</a></h5>
                            <div class=\"simpleCart_shelfItem\">
                                <p class=\"flexisel_ecommerce_cart\"><span>\$312</span> <i class=\"item_price\">\$212</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class=\"w3l_related_products_grid\">
                        <div class=\"agile_ecommerce_tab_left dresses_grid\">
                            <div class=\"hs-wrapper hs-wrapper3\">
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <div class=\"w3_hs_bottom\">
                                    <div class=\"flex_ecommerce\">
                                        <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                    </div>
                                </div>
                            </div>
                            <h5><a href=\"single.html\">Black Shorts</a></h5>
                            <div class=\"simpleCart_shelfItem\">
                                <p class=\"flexisel_ecommerce_cart\"><span>\$432</span> <i class=\"item_price\">\$323</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class=\"w3l_related_products_grid\">
                        <div class=\"agile_ecommerce_tab_left dresses_grid\">
                            <div class=\"hs-wrapper hs-wrapper3\">
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <div class=\"w3_hs_bottom\">
                                    <div class=\"flex_ecommerce\">
                                        <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                    </div>
                                </div>
                            </div>
                            <h5><a href=\"single.html\">White Skirts</a></h5>
                            <div class=\"simpleCart_shelfItem\">
                                <p class=\"flexisel_ecommerce_cart\"><span>\$323</span> <i class=\"item_price\">\$310</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class=\"w3l_related_products_grid\">
                        <div class=\"agile_ecommerce_tab_left dresses_grid\">
                            <div class=\"hs-wrapper hs-wrapper3\">
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/41.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/27.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/28.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/37.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/30.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/36.jpg\" alt=\" \" class=\"img-responsive\" />
                                <img src=\"images/38.jpg\" alt=\" \" class=\"img-responsive\" />
                                <div class=\"w3_hs_bottom\">
                                    <div class=\"flex_ecommerce\">
                                        <a href=\"#\" data-toggle=\"modal\" data-target=\"#myModal6\"><span class=\"glyphicon glyphicon-eye-open\" aria-hidden=\"true\"></span></a>
                                    </div>
                                </div>
                            </div>
                            <h5><a href=\"single.html\">Long Skirts</a></h5>
                            <div class=\"simpleCart_shelfItem\">
                                <p class=\"flexisel_ecommerce_cart\"><span>\$256</span> <i class=\"item_price\">\$200</i></p>
                                <p><a class=\"item_add\" href=\"#\">Add to cart</a></p>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
            <script type=\"text/javascript\">
                \$(window).load(function() {
                    \$(\"#flexiselDemo2\").flexisel({
                        visibleItems:4,
                        animationSpeed: 1000,
                        autoPlay: true,
                        autoPlaySpeed: 3000,
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: {
                            portrait: {
                                changePoint:480,
                                visibleItems: 1
                            },
                            landscape: {
                                changePoint:640,
                                visibleItems:2
                            },
                            tablet: {
                                changePoint:768,
                                visibleItems: 3
                            }
                        }
                    });

                });
            </script>
            <script type=\"text/javascript\" src=\"js/jquery.flexisel.js\"></script>
        </div>
    </div>
    <!-- //dresses -->
{% endblock %}
", "products/index.html.twig", "E:\\PIDEV_WEB\\Sport\\templates\\products\\index.html.twig");
    }
}
