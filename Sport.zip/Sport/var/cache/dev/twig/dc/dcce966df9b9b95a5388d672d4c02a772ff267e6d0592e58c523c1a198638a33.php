<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* about/index.html.twig */
class __TwigTemplate_3f1f1f41878ebe4f124964d747a16ee1d3b1d3ebae27da3cf8a25c32e6bf977d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'actAbout' => [$this, 'block_actAbout'],
            'ShowLogin' => [$this, 'block_ShowLogin'],
            'banner' => [$this, 'block_banner'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "about/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "about/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "about/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello AboutController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 4
    public function block_actAbout($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actAbout"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "actAbout"));

        echo " class=\"act\" ";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_ShowLogin($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "ShowLogin"));

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 7
    public function block_banner($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "banner"));

        // line 8
        echo "    <div class=\"banner10\" id=\"home1\">
        <div class=\"container\">
            <h2>About Us</h2>
        </div>
    </div>
    <!-- //banner -->

    <!-- breadcrumbs -->
    <div class=\"breadcrumb_dress\">
        <div class=\"container\">
            <ul>
                <li><a href=\"";
        // line 19
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        echo "\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i></li>
                <li>About Us</li>
            </ul>
        </div>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 25
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 26
        echo "    <div class=\"about\">
        <div class=\"container\">
            <div class=\"w3ls_about_grids\">
                <div class=\"col-md-6 w3ls_about_grid_left\">
                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        cupidatat non proident, sunt in culpa qui officia deserunt mollit
                        anim id est laborum.</p>
                    <div class=\"col-xs-2 w3ls_about_grid_left1\">
                        <span class=\"glyphicon glyphicon-new-window\" aria-hidden=\"true\"></span>
                    </div>
                    <div class=\"col-xs-10 w3ls_about_grid_left2\">
                        <p>Sunt in culpa qui officia deserunt mollit
                            anim id est laborum.Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</p>
                    </div>
                    <div class=\"clearfix\"> </div>
                    <div class=\"col-xs-2 w3ls_about_grid_left1\">
                        <span class=\"glyphicon glyphicon-flash\" aria-hidden=\"true\"></span>
                    </div>
                    <div class=\"col-xs-10 w3ls_about_grid_left2\">
                        <p>Sunt in culpa qui officia deserunt mollit
                            anim id est laborum.Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</p>
                    </div>
                    <div class=\"clearfix\"> </div>
                </div>
                <div class=\"col-md-6 w3ls_about_grid_right\">
                    <img src=\"images/77.jpg\" alt=\" \" class=\"img-responsive\" />
                </div>
                <div class=\"clearfix\"> </div>
            </div>
        </div>
    </div>
    <!-- //about -->

    <!-- team -->
    <div class=\"team\">
        <div class=\"container\">
            <h3>Meet Our Team</h3>
            <div class=\"wthree_team_grids\">
                <div class=\"col-md-3 wthree_team_grid\">
                    <img src=\"images/8.png\" alt=\" \" class=\"img-responsive\" />
                    <h4>Smith Allen <span>Fashion Designer</span></h4>
                    <div class=\"agileits_social_button\">
                        <ul>
                            <li><a href=\"#\" class=\"facebook\"> </a></li>
                            <li><a href=\"#\" class=\"twitter\"> </a></li>
                            <li><a href=\"#\" class=\"google\"> </a></li>
                            <li><a href=\"#\" class=\"pinterest\"> </a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-md-3 wthree_team_grid\">
                    <img src=\"images/9.png\" alt=\" \" class=\"img-responsive\" />
                    <h4>Laura James <span>Fashion Designer</span></h4>
                    <div class=\"agileits_social_button\">
                        <ul>
                            <li><a href=\"#\" class=\"facebook\"> </a></li>
                            <li><a href=\"#\" class=\"twitter\"> </a></li>
                            <li><a href=\"#\" class=\"google\"> </a></li>
                            <li><a href=\"#\" class=\"pinterest\"> </a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-md-3 wthree_team_grid\">
                    <img src=\"images/10.png\" alt=\" \" class=\"img-responsive\" />
                    <h4>Crisp Doe <span>Fashion Designer</span></h4>
                    <div class=\"agileits_social_button\">
                        <ul>
                            <li><a href=\"#\" class=\"facebook\"> </a></li>
                            <li><a href=\"#\" class=\"twitter\"> </a></li>
                            <li><a href=\"#\" class=\"google\"> </a></li>
                            <li><a href=\"#\" class=\"pinterest\"> </a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-md-3 wthree_team_grid\">
                    <img src=\"images/11.png\" alt=\" \" class=\"img-responsive\" />
                    <h4>Linda Rosy <span>Fashion Designer</span></h4>
                    <div class=\"agileits_social_button\">
                        <ul>
                            <li><a href=\"#\" class=\"facebook\"> </a></li>
                            <li><a href=\"#\" class=\"twitter\"> </a></li>
                            <li><a href=\"#\" class=\"google\"> </a></li>
                            <li><a href=\"#\" class=\"pinterest\"> </a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"clearfix\"> </div>
                <p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
                    voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
                    repellat.</p>
            </div>
        </div>
    </div>
    <!-- //team -->
    <!-- team-bottom -->
    <div class=\"team-bottom\">
        <div class=\"container\">
            <h3>Are You Ready For Awesomeness? Flat <span>50% Offer</span> For Women's</h3>
            <p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
                voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
                repellat.</p>
            <a href=\"dresses.html\">Shop Now</a>
        </div>
    </div>
    <!-- //team-bottom -->
    <!-- newsletter -->
    <div class=\"newsletter\">
        <div class=\"container\">
            <div class=\"col-md-6 w3agile_newsletter_left\">
                <h3>Newsletter</h3>
                <p>Excepteur sint occaecat cupidatat non proident, sunt.</p>
            </div>
            <div class=\"col-md-6 w3agile_newsletter_right\">
                <form action=\"#\" method=\"post\">
                    <input type=\"email\" name=\"Email\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">
                    <input type=\"submit\" value=\"\">
                </form>
            </div>
            <div class=\"clearfix\"> </div>
        </div>
    </div>
    <!-- //newsletter -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "about/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  167 => 26,  157 => 25,  141 => 19,  128 => 8,  118 => 7,  100 => 5,  81 => 4,  62 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello AboutController!{% endblock %}
{% block actAbout%} class=\"act\" {% endblock %}
{% block ShowLogin %}
{% endblock %}
{% block banner %}
    <div class=\"banner10\" id=\"home1\">
        <div class=\"container\">
            <h2>About Us</h2>
        </div>
    </div>
    <!-- //banner -->

    <!-- breadcrumbs -->
    <div class=\"breadcrumb_dress\">
        <div class=\"container\">
            <ul>
                <li><a href=\"{{ path('home') }}\"><span class=\"glyphicon glyphicon-home\" aria-hidden=\"true\"></span> Home</a> <i>/</i></li>
                <li>About Us</li>
            </ul>
        </div>
    </div>
{% endblock %}
{% block body %}
    <div class=\"about\">
        <div class=\"container\">
            <div class=\"w3ls_about_grids\">
                <div class=\"col-md-6 w3ls_about_grid_left\">
                    <p>Duis aute irure dolor in reprehenderit in voluptate velit esse
                        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        cupidatat non proident, sunt in culpa qui officia deserunt mollit
                        anim id est laborum.</p>
                    <div class=\"col-xs-2 w3ls_about_grid_left1\">
                        <span class=\"glyphicon glyphicon-new-window\" aria-hidden=\"true\"></span>
                    </div>
                    <div class=\"col-xs-10 w3ls_about_grid_left2\">
                        <p>Sunt in culpa qui officia deserunt mollit
                            anim id est laborum.Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</p>
                    </div>
                    <div class=\"clearfix\"> </div>
                    <div class=\"col-xs-2 w3ls_about_grid_left1\">
                        <span class=\"glyphicon glyphicon-flash\" aria-hidden=\"true\"></span>
                    </div>
                    <div class=\"col-xs-10 w3ls_about_grid_left2\">
                        <p>Sunt in culpa qui officia deserunt mollit
                            anim id est laborum.Duis aute irure dolor in reprehenderit in voluptate velit esse
                            cillum dolore eu fugiat nulla pariatur.</p>
                    </div>
                    <div class=\"clearfix\"> </div>
                </div>
                <div class=\"col-md-6 w3ls_about_grid_right\">
                    <img src=\"images/77.jpg\" alt=\" \" class=\"img-responsive\" />
                </div>
                <div class=\"clearfix\"> </div>
            </div>
        </div>
    </div>
    <!-- //about -->

    <!-- team -->
    <div class=\"team\">
        <div class=\"container\">
            <h3>Meet Our Team</h3>
            <div class=\"wthree_team_grids\">
                <div class=\"col-md-3 wthree_team_grid\">
                    <img src=\"images/8.png\" alt=\" \" class=\"img-responsive\" />
                    <h4>Smith Allen <span>Fashion Designer</span></h4>
                    <div class=\"agileits_social_button\">
                        <ul>
                            <li><a href=\"#\" class=\"facebook\"> </a></li>
                            <li><a href=\"#\" class=\"twitter\"> </a></li>
                            <li><a href=\"#\" class=\"google\"> </a></li>
                            <li><a href=\"#\" class=\"pinterest\"> </a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-md-3 wthree_team_grid\">
                    <img src=\"images/9.png\" alt=\" \" class=\"img-responsive\" />
                    <h4>Laura James <span>Fashion Designer</span></h4>
                    <div class=\"agileits_social_button\">
                        <ul>
                            <li><a href=\"#\" class=\"facebook\"> </a></li>
                            <li><a href=\"#\" class=\"twitter\"> </a></li>
                            <li><a href=\"#\" class=\"google\"> </a></li>
                            <li><a href=\"#\" class=\"pinterest\"> </a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-md-3 wthree_team_grid\">
                    <img src=\"images/10.png\" alt=\" \" class=\"img-responsive\" />
                    <h4>Crisp Doe <span>Fashion Designer</span></h4>
                    <div class=\"agileits_social_button\">
                        <ul>
                            <li><a href=\"#\" class=\"facebook\"> </a></li>
                            <li><a href=\"#\" class=\"twitter\"> </a></li>
                            <li><a href=\"#\" class=\"google\"> </a></li>
                            <li><a href=\"#\" class=\"pinterest\"> </a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"col-md-3 wthree_team_grid\">
                    <img src=\"images/11.png\" alt=\" \" class=\"img-responsive\" />
                    <h4>Linda Rosy <span>Fashion Designer</span></h4>
                    <div class=\"agileits_social_button\">
                        <ul>
                            <li><a href=\"#\" class=\"facebook\"> </a></li>
                            <li><a href=\"#\" class=\"twitter\"> </a></li>
                            <li><a href=\"#\" class=\"google\"> </a></li>
                            <li><a href=\"#\" class=\"pinterest\"> </a></li>
                        </ul>
                    </div>
                </div>
                <div class=\"clearfix\"> </div>
                <p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
                    voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
                    repellat.</p>
            </div>
        </div>
    </div>
    <!-- //team -->
    <!-- team-bottom -->
    <div class=\"team-bottom\">
        <div class=\"container\">
            <h3>Are You Ready For Awesomeness? Flat <span>50% Offer</span> For Women's</h3>
            <p>Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis
                voluptatibus maiores alias consequatur aut perferendis doloribus asperiores
                repellat.</p>
            <a href=\"dresses.html\">Shop Now</a>
        </div>
    </div>
    <!-- //team-bottom -->
    <!-- newsletter -->
    <div class=\"newsletter\">
        <div class=\"container\">
            <div class=\"col-md-6 w3agile_newsletter_left\">
                <h3>Newsletter</h3>
                <p>Excepteur sint occaecat cupidatat non proident, sunt.</p>
            </div>
            <div class=\"col-md-6 w3agile_newsletter_right\">
                <form action=\"#\" method=\"post\">
                    <input type=\"email\" name=\"Email\" value=\"Email\" onfocus=\"this.value = '';\" onblur=\"if (this.value == '') {this.value = 'Email';}\" required=\"\">
                    <input type=\"submit\" value=\"\">
                </form>
            </div>
            <div class=\"clearfix\"> </div>
        </div>
    </div>
    <!-- //newsletter -->
{% endblock %}

", "about/index.html.twig", "E:\\PIDEV_WEB\\Sport\\templates\\about\\index.html.twig");
    }
}
